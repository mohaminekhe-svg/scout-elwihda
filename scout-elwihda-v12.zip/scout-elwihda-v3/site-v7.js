/* =========================================================
   site-v7.js — مرحلة المنصة المتكاملة (تُحمَّل بعد site-v6.js)
   سجل النشاطات • مركز الموافقات • إدارة الحسابات (عرض/طباعة A4/بريد) • الدعم الفني
   تعليقات بالردود والإعجاب العادي والرسمي • البحث الشامل • النسخ الاحتياطي (واجهة لـ Cloud Functions)
   لا أسرار هنا. كل الصلاحيات الفعلية في firestore.rules وفي Cloud Functions (انظر functions/).
   ========================================================= */
(function () {
  'use strict';
  var V7 = window.V7 = window.V7 || {};
  function $(id) { return document.getElementById(id); }
  function H() { return (window.V5 && V5.helpers) || {}; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function me() { return (window.V5 && V5.me) || {}; }
  function isAdmin() { var m = me(); return !!(m.data && m.data.role === 'admin' && m.data.accountStatus !== 'suspended'); }
  function msOf(ts) { return ts && ts.toMillis ? ts.toMillis() : null; }
  function ts() { return firebase.firestore.FieldValue.serverTimestamp(); }
  function dt(ms) { try { return new Intl.DateTimeFormat('ar-DZ', { timeZone: 'Africa/Algiers', dateStyle: 'medium', timeStyle: 'short' }).format(new Date(ms)); } catch (e) { return ''; } }
  function day(ms) { try { return new Intl.DateTimeFormat('ar-DZ', { timeZone: 'Africa/Algiers', dateStyle: 'long' }).format(new Date(ms)); } catch (e) { return ''; } }
  function toast(m, t) { if (typeof showAdminNotification === 'function') showAdminNotification(m, t || 'info'); }
  function say(id, t, ok) { var e = $(id); if (e) { e.textContent = t || ''; e.classList.toggle('bad', !ok && !!t); } }
  function errTxt(e, what) { return (window.V3 && V3.dbErrorText) ? V3.dbErrorText(e, what) : ('تعذّر ' + what + ' (' + ((e && e.code) || 'خطأ') + ')'); }

  /* ---------- الأدوار ---------- */
  function roleLabel(d) {
    if (!d) return '';
    if (d.role === 'admin') return 'قائد الفوج';
    if (d.role === 'media_manager' || d.leaderRoleTitle === 'مسؤول إعلام') return 'مسؤول الإعلام';
    if (d.role === 'leader') return 'قائد وحدة';
    if (d.role === 'scout') return 'كشاف';
    if (d.role === 'parent') return 'ولي أمر';
    return d.role || '';
  }
  V7.roleLabel = roleLabel;
  function nameOf(d) { return (d && (d.fullName || ((d.firstName || '') + ' ' + (d.lastName || '')).trim())) || 'مستخدم'; }
  function avatar(d, cls) {
    var u = d && d.photoURL && typeof safeImgUrl === 'function' ? safeImgUrl(d.photoURL) : '';
    return '<span class="avatar-circle ' + (cls || 'avatar-sm') + '">' + (u ? '<img class="avatar-img" src="' + esc(u) + '" alt="" loading="lazy" onerror="this.remove()">' : '<i class="fa-solid fa-user avatar-ph" aria-hidden="true"></i>') + '</span>';
  }

  /* =========================================================
     1) سجل النشاطات الإدارية (إضافة فقط)
     ========================================================= */
  var loggedLogin = false;
  V7.log = function (action, targetType, targetId, label, result) {
    var m = me(); if (!m.uid || !m.data) return Promise.resolve();
    return db.collection('adminLogs').add({
      actorUid: m.uid, actorName: String(nameOf(m.data)).slice(0, 80), actorRole: roleLabel(m.data),
      action: String(action).slice(0, 60), targetType: String(targetType || ''), targetId: String(targetId || ''), targetLabel: String(label || '').slice(0, 120),
      result: String(result || 'ok').slice(0, 120), createdAt: ts()
    }).catch(function (e) { console.warn('[Scout Elwihda] log failed:', e && e.code); });
  };
  var ACTION_LABELS = { admin_login: 'تسجيل دخول إداري', approve_request: 'الموافقة على طلب', reject_request: 'رفض طلب', role_change: 'تغيير صلاحيات', notice_create: 'إنشاء إشعار', notice_update: 'تعديل إشعار', notice_delete: 'حذف إشعار', email_sent: 'إرسال بريد', email_failed: 'فشل إرسال بريد', support_update: 'تحديث بلاغ دعم', official_like: 'إعجاب رسمي', official_like_remove: 'إزالة إعجاب رسمي', comment_delete: 'حذف تعليق', backup_create: 'إنشاء نسخة احتياطية', backup_restore: 'استعادة نسخة', backup_download: 'تنزيل نسخة', print_profile: 'طباعة ملف حساب', unit_change_approve: 'الموافقة على تغيير وحدة', announcement_delete: 'حذف منشور/إعلان' };
  function loadLogs() {
    if (!isAdmin()) { say('logsMsg', 'هذه الصفحة للأدمن فقط.'); return; }
    db.collection('adminLogs').orderBy('createdAt', 'desc').limit(200).get().then(function (snap) {
      var arr = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; arr.push(x); });
      $('logsList').innerHTML = arr.length ? arr.map(function (l) {
        return '<div class="v3-admin-row"><div class="v3-admin-info"><strong>' + esc(ACTION_LABELS[l.action] || l.action) + '</strong> <span class="v3-chip ' + (/fail|error|reject/i.test(l.result + l.action) ? 'off' : 'on') + '">' + esc(l.result) + '</span>' +
          '<p class="v3-muted">' + esc(l.actorName) + ' (' + esc(l.actorRole) + ') • ' + esc(msOf(l.createdAt) ? dt(msOf(l.createdAt)) : '') + (l.targetLabel ? ' • ' + esc(l.targetLabel) : '') + '</p></div></div>';
      }).join('') : '<p class="v3-muted">لا توجد سجلات بعد.</p>'; say('logsMsg', '');
    }).catch(function (e) { say('logsMsg', errTxt(e, 'تحميل السجل')); });
  }

  /* =========================================================
     2) مركز الموافقات
     ========================================================= */
  function inboxFor(uid, title, body, link) {
    var m = me();
    return db.collection('users').doc(uid).collection('inbox').add({ type: 'role_result', title: title, body: body, issuer: 'قائد الفوج', issuerName: nameOf(m.data), link: link || '', createdAt: ts() });
  }
  function loadApprovals() {
    if (!isAdmin()) { say('apprMsg', 'هذه الصفحة للأدمن فقط.'); return; }
    db.collection('users').where('accountStatus', '==', 'pending_verification').get().then(function (snap) {
      var arr = []; snap.forEach(function (d) { var x = d.data(); x.uid = d.id; if (x.role === 'leader' || x.role === 'media_manager') arr.push(x); });   // طلبات المناصب فقط
      arr.sort(function (a, b) { return (msOf(b.createdAt) || 0) - (msOf(a.createdAt) || 0); });
      var box = $('apprList');
      if (!arr.length) { box.innerHTML = '<p class="v3-muted">لا توجد طلبات معلقة.</p>'; return; }
      box.innerHTML = arr.map(function (u) {
        return '<div class="v3-admin-row appr-row" data-uid="' + esc(u.uid) + '"><div class="v3-admin-info appr-info">' + avatar(u, 'avatar-md') +
          '<div><strong>' + esc(nameOf(u)) + '</strong><p class="v3-muted" dir="ltr">' + esc(u.email || '') + '</p><p class="v3-muted">الصفة المطلوبة: <b>' + esc(roleLabel(u)) + '</b>' + (u.unit ? ' — ' + esc(u.unit) : '') + ' • ' + esc(msOf(u.createdAt) ? day(msOf(u.createdAt)) : 'تاريخ غير مسجّل') + '</p><span class="v3-chip off">قيد المراجعة</span></div></div>' +
          '<div class="v3-admin-btns"><button type="button" data-a="ok">موافقة</button><button type="button" data-a="no" class="danger">رفض</button></div></div>';
      }).join('');
      box.querySelectorAll('.appr-row').forEach(function (row) {
        var uid = row.getAttribute('data-uid'), u = arr.filter(function (x) { return x.uid === uid; })[0];
        row.querySelectorAll('button').forEach(function (b) { b.addEventListener('click', function () { decide(u, b.getAttribute('data-a') === 'ok', b); }); });
      });
    }).catch(function (e) { say('apprMsg', errTxt(e, 'تحميل الطلبات')); });
  }
  function decide(u, ok, btn) {
    if (!isAdmin()) return;
    if (!window.confirm((ok ? 'الموافقة على' : 'رفض') + ' طلب ' + nameOf(u) + '؟')) return;
    btn.disabled = true;
    var isMedia = roleLabel(u) === 'مسؤول الإعلام';
    var upd = ok ? { accountStatus: 'active', verificationStatus: 'verified', updatedAt: ts() } : { accountStatus: 'rejected', verificationStatus: 'rejected', updatedAt: ts() };
    // نفس سياسة الموافقة الحالية: مسؤول الإعلام يحصل على صلاحيات الإعلام الأساسية فقط، وغيره بلا صلاحيات تلقائية
    if (ok && isMedia) { upd.permissions = { 'media.portal': true, 'announcements.view': true, 'announcements.create': true, 'announcements.edit': true, 'gallery.view': true, 'gallery.upload': true }; upd.leaderRoleTitle = 'مسؤول إعلام'; }
    var bt = db.batch(); bt.update(db.collection('users').doc(u.uid), upd);
    bt.update(db.collection('leaders').doc(u.uid), upd);
    bt.commit().then(function () {
      return inboxFor(u.uid, ok ? 'تمت الموافقة على طلبك' : 'تم رفض طلبك', ok ? ('وافق قائد الفوج على اعتمادك بصفة «' + roleLabel(u) + '». يمكنك الآن استخدام صلاحيات حسابك.') : ('تعذّرت الموافقة على طلب اعتمادك بصفة «' + roleLabel(u) + '». للاستفسار راسل الدعم الفني.'), '').catch(function () {});
    }).then(function () { return V7.log(ok ? 'approve_request' : 'reject_request', 'user', u.uid, nameOf(u) + ' — ' + roleLabel(u), 'ok'); })
      .then(function () { say('apprMsg', ok ? 'تمت الموافقة وأُرسل إشعار لصاحب الطلب.' : 'تم الرفض وأُرسل إشعار لصاحب الطلب.', true); loadApprovals(); })
      .catch(function (e) { V7.log(ok ? 'approve_request' : 'reject_request', 'user', u.uid, nameOf(u), 'فشل: ' + (e && e.code)); say('apprMsg', errTxt(e, 'تنفيذ القرار')); btn.disabled = false; });
  }

  /* =========================================================
     3) إدارة الحسابات: تصنيفات + بحث + عرض/طباعة A4/بريد
     ========================================================= */
  var accAll = [], accCat = 'scout', accQ = '';
  function catOf(u) {
    if (u.accountStatus === 'pending_verification') return 'pending';
    if (u.accountStatus === 'rejected') return 'rejected';
    if (u.role === 'media_manager' || u.leaderRoleTitle === 'مسؤول إعلام') return 'media';
    if (u.role === 'leader' || u.role === 'admin') return 'leader';
    if (u.role === 'parent') return 'parent';
    return 'scout';
  }
  function norm(s) { return String(s || '').toLowerCase().replace(/[\u064B-\u065F\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').trim(); }
  V7.norm = norm;
  function loadAccounts() {
    if (!isAdmin()) { say('accMsg', 'هذه الصفحة للأدمن فقط.'); return; }
    db.collection('users').get().then(function (snap) { accAll = []; snap.forEach(function (d) { var x = d.data(); x.uid = d.id; accAll.push(x); }); renderAccounts(); say('accMsg', ''); })
      .catch(function (e) { say('accMsg', errTxt(e, 'تحميل الحسابات')); });
  }
  function renderAccounts() {
    var q = norm(accQ);
    var list = accAll.filter(function (u) { return catOf(u) === accCat && (!q || norm(nameOf(u) + ' ' + (u.email || '') + ' ' + (u.nickname || '')).indexOf(q) !== -1); })
      .sort(function (a, b) { return nameOf(a).localeCompare(nameOf(b), 'ar'); });
    document.querySelectorAll('#accCats .acc-cat').forEach(function (b) { var c = b.getAttribute('data-cat'); b.classList.toggle('on', c === accCat); var n = accAll.filter(function (u) { return catOf(u) === c; }).length; b.setAttribute('data-n', n); });
    var box = $('accList'); if (!box) return;
    box.innerHTML = list.length ? list.map(function (u) {
      return '<div class="v3-admin-row acc-row" data-uid="' + esc(u.uid) + '"><div class="v3-admin-info appr-info">' + avatar(u) + '<div><strong>' + esc(nameOf(u)) + '</strong> <span class="v3-chip ' + (u.accountStatus === 'active' ? 'on' : 'off') + '">' + esc(roleLabel(u)) + '</span><p class="v3-muted" dir="ltr">' + esc(u.email || '') + '</p></div></div>' +
        '<div class="v3-admin-btns"><button type="button" data-a="view">عرض الملف</button><button type="button" data-a="print">طباعة</button><button type="button" data-a="mail">إرسال رسالة</button></div></div>';
    }).join('') : '<p class="v3-muted">لا توجد حسابات في هذا التصنيف.</p>';
    box.querySelectorAll('.acc-row').forEach(function (row) {
      var u = accAll.filter(function (x) { return x.uid === row.getAttribute('data-uid'); })[0];
      row.querySelectorAll('button').forEach(function (b) { b.addEventListener('click', function () { var a = b.getAttribute('data-a'); if (a === 'view') viewProfile(u); else if (a === 'print') printProfile(u); else openEmail(u); }); });
    });
  }
  var viewing = null;
  function fieldRows(u, withStatus) {
    var rows = [['الاسم', nameOf(u)], ['اللقب', u.nickname], ['رقم الهاتف', u.scoutPhone || u.parentPhone || u.phone], ['البريد الإلكتروني', u.email], ['تاريخ الميلاد', u.birthDate ? day(new Date(u.birthDate + 'T12:00:00+01:00').getTime()) : ''], ['الوحدة الكشفية', u.unit], ['فصيلة الدم', u.bloodType]];
    if (withStatus) { rows.push(['الصفة', roleLabel(u)]); rows.push(['حالة الحساب', u.accountStatus === 'active' ? 'نشط' : (u.accountStatus === 'pending_verification' ? 'قيد المراجعة' : (u.accountStatus || ''))]); }
    return rows;
  }
  function viewProfile(u) {
    if (!isAdmin()) return; viewing = u;
    $('pvBody').innerHTML = '<div class="profile-head">' + avatar(u, 'avatar-xl') + '<div><h4>' + esc(nameOf(u)) + '</h4><p class="profile-role">' + esc(roleLabel(u)) + '</p></div></div><dl class="profile-grid">' +
      fieldRows(u, true).filter(function (r) { return r[1]; }).map(function (r) { return '<div><dt>' + esc(r[0]) + '</dt><dd' + (r[0] === 'البريد الإلكتروني' || r[0] === 'رقم الهاتف' ? ' dir="ltr"' : '') + '>' + esc(r[1]) + '</dd></div>'; }).join('') + '</dl>';
    openModal('profileViewModal');
  }
  // طباعة A4: لا كلمات مرور، لا UID، لا تاريخ إنشاء، ولا بيانات تقنية. فصيلة الدم فقط إن سُجّلت.
  function printProfile(u) {
    if (!isAdmin()) { toast('الطباعة للمخوَّلين فقط.', 'error'); return; }
    var logoA = 'logo%20sma.png', logoB = 'logo%20elwihda.png';
    var photo = u.photoURL && typeof safeImgUrl === 'function' ? safeImgUrl(u.photoURL) : '';
    var rows = fieldRows(u, false).filter(function (r) { return r[1]; });
    $('printSheet').innerHTML = '<div class="ps-page"><header class="ps-head"><img src="' + logoA + '" alt=""><div><h1>الكشافة الإسلامية الجزائرية — فوج الوحدة</h1><p>ملف شخصي</p></div><img src="' + logoB + '" alt=""></header>' +
      '<div class="ps-photo">' + (photo ? '<img src="' + esc(photo) + '" alt="">' : '') + '</div><table class="ps-table"><tbody>' + rows.map(function (r) { return '<tr><th>' + esc(r[0]) + '</th><td' + (r[0] === 'البريد الإلكتروني' || r[0] === 'رقم الهاتف' ? ' dir="ltr"' : '') + '>' + esc(r[1]) + '</td></tr>'; }).join('') + '</tbody></table>' +
      '<footer class="ps-foot">طُبع بتاريخ ' + esc(day(Date.now())) + '</footer></div>';
    document.body.classList.add('printing-profile');
    V7.log('print_profile', 'user', u.uid, nameOf(u), 'ok');
    setTimeout(function () { window.print(); }, 150);
  }
  V7.printProfile = printProfile;
  window.addEventListener('afterprint', function () { document.body.classList.remove('printing-profile'); });

  /* ---------- البريد (Cloud Function) ---------- */
  var mailTarget = null, lastMail = 0;
  function openEmail(u) {
    if (!isAdmin()) return;
    if (!u.email) { toast('لا يوجد بريد إلكتروني مسجّل لهذا الحساب.', 'warning'); return; }
    mailTarget = u; $('emTo').value = u.email; $('emSubject').value = ''; $('emBody').value = ''; say('emStatus', ''); closeModal('profileViewModal'); openModal('emailModal');
  }
  function initEmail() {
    var f = $('emailForm'); if (!f) return;
    f.addEventListener('submit', function (e) {
      e.preventDefault(); if (!isAdmin() || !mailTarget) return;
      var subj = $('emSubject').value.trim(), body = $('emBody').value.trim();
      if (subj.length < 3 || subj.length > 150) { say('emStatus', 'الموضوع بين 3 و150 حرفًا.'); return; }
      if (body.length < 5 || body.length > 5000) { say('emStatus', 'الرسالة بين 5 و5000 حرف.'); return; }
      if (Date.now() - lastMail < 8000) { say('emStatus', 'انتظر قليلًا قبل إرسال رسالة أخرى.'); return; }
      if (!firebase.functions) { say('emStatus', 'خدمة Cloud Functions غير محمّلة في هذه الصفحة.'); return; }
      lastMail = Date.now(); var btn = $('emSend'); btn.disabled = true; say('emStatus', 'جاري الإرسال…', true);
      firebase.functions().httpsCallable('sendAdminEmail')({ toUid: mailTarget.uid, subject: subj, body: body }).then(function (r) {
        if (r && r.data && r.data.ok === true) { say('emStatus', 'تم إرسال الرسالة (تأكيد الخدمة).', true); V7.log('email_sent', 'user', mailTarget.uid, mailTarget.email, 'ok'); }
        else { say('emStatus', 'لم تؤكد الخدمة نجاح الإرسال.'); V7.log('email_failed', 'user', mailTarget.uid, mailTarget.email, 'بلا تأكيد'); }
      }).catch(function (er) {
        var c = er && er.code || '';
        say('emStatus', (c === 'functions/not-found' || c === 'functions/unavailable' || c === 'functions/internal') ? 'خدمة البريد غير مُعدّة بعد على الخادم (Cloud Function sendAdminEmail). راجع functions/README_AR.md.' : ('تعذّر الإرسال: ' + ((er && er.message) || c)));
        V7.log('email_failed', 'user', mailTarget.uid, mailTarget.email, 'فشل: ' + c);
      }).then(function () { btn.disabled = false; });
    });
    var pp = $('pvPrint'); if (pp) pp.addEventListener('click', function () { if (viewing) printProfile(viewing); });
    var pe = $('pvEmail'); if (pe) pe.addEventListener('click', function () { if (viewing) openEmail(viewing); });
    document.querySelectorAll('#accCats .acc-cat').forEach(function (b) { b.addEventListener('click', function () { accCat = b.getAttribute('data-cat'); renderAccounts(); }); });
    var s = $('accSearch'); if (s) s.addEventListener('input', function () { accQ = s.value; renderAccounts(); });
  }

  /* =========================================================
     4) الدعم الفني: بلاغات المستخدم + إدارة البلاغات
     ========================================================= */
  var ST = { 'new': 'جديد', 'in_progress': 'قيد المعالجة', 'resolved': 'تم الحل' }, TY = { account: 'الحساب', upload: 'رفع الصور', content: 'المحتوى', bug: 'خلل في الموقع', other: 'أخرى' };
  var tkImg = null, tkBusy = false;
  function initTickets() {
    var f = $('ticketForm'); if (!f) return;
    if ($('tkImageUploader') && window.SEImage) tkImg = SEImage.mount($('tkImageUploader'), { kind: 'profiles', shape: 'rect', label: 'اختيار صورة' });
    f.addEventListener('submit', function (e) {
      e.preventDefault(); var m = me(); if (!m.uid || !m.data || m.data.accountStatus !== 'active') { say('ticketMsg', 'حسابك غير نشط بعد.'); return; }
      var title = $('tkTitle').value.trim(), desc = $('tkDesc').value.trim();
      if (title.length < 3) { say('ticketMsg', 'العنوان قصير جدًا.'); return; } if (desc.length < 5) { say('ticketMsg', 'اشرح المشكلة بوضوح أكثر.'); return; }
      if (tkBusy) return; tkBusy = true; $('ticketSubmit').disabled = true; say('ticketMsg', 'جاري الإرسال…', true);
      (tkImg ? tkImg.commit() : Promise.resolve({ unchanged: true })).then(function (img) {
        var d = { uid: m.uid, userName: String(nameOf(m.data)).slice(0, 80), type: $('tkType').value, title: title, description: desc, status: 'new', createdAt: ts(), updatedAt: ts() };
        if (img && img.imageUrl) { d.imageUrl = img.imageUrl; d.driveFileId = img.driveFileId; }
        return db.collection('supportTickets').add(d);
      }).then(function () { say('ticketMsg', 'أُرسل بلاغك. يمكنك متابعته أدناه.', true); f.reset(); if (tkImg) tkImg.reset(null); loadMyTickets(); })
        .catch(function (er) { say('ticketMsg', er && er.isUploadError ? ('تعذّر رفع الصورة: ' + er.message) : errTxt(er, 'إرسال البلاغ')); })
        .then(function () { tkBusy = false; $('ticketSubmit').disabled = false; });
    });
  }
  function loadMyTickets() {
    var m = me(); var box = $('myTickets'); if (!box || !m.uid) return;
    db.collection('supportTickets').where('uid', '==', m.uid).get().then(function (snap) {
      var arr = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; arr.push(x); }); arr.sort(function (a, b) { return (msOf(b.createdAt) || 0) - (msOf(a.createdAt) || 0); });
      box.innerHTML = arr.length ? arr.map(function (t) {
        return '<article class="ticket"><div class="ticket-top"><strong>' + esc(t.title) + '</strong><span class="tk-st tk-' + esc(t.status) + '">' + esc(ST[t.status] || t.status) + '</span></div><p class="v3-muted">' + esc(TY[t.type] || t.type) + ' • ' + esc(msOf(t.createdAt) ? dt(msOf(t.createdAt)) : '') + '</p><p class="ticket-desc">' + esc(t.description) + '</p>' +
          (t.adminReply ? '<div class="ticket-reply"><b>رد الدعم:</b> ' + esc(t.adminReply) + '</div>' : '') + '</article>';
      }).join('') : '<p class="v3-muted">لا توجد بلاغات.</p>';
    }).catch(function (e) { box.innerHTML = '<p class="v5-msg bad">' + esc(errTxt(e, 'تحميل بلاغاتك')) + '</p>'; });
  }
  V7.loadMyTickets = loadMyTickets;
  var tkFilter = 'all';
  function loadTicketsAdmin() {
    if (!isAdmin()) { say('tkAdminMsg', 'هذه الصفحة للأدمن فقط.'); return; }
    db.collection('supportTickets').get().then(function (snap) {
      var arr = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; arr.push(x); }); arr.sort(function (a, b) { return (msOf(b.createdAt) || 0) - (msOf(a.createdAt) || 0); });
      arr = arr.filter(function (t) { return tkFilter === 'all' || t.status === tkFilter; });
      var box = $('tkAdminList');
      box.innerHTML = arr.length ? arr.map(function (t) {
        return '<div class="v3-admin-row tk-row" data-id="' + esc(t.id) + '"><div class="v3-admin-info"><strong>' + esc(t.title) + '</strong> <span class="tk-st tk-' + esc(t.status) + '">' + esc(ST[t.status] || t.status) + '</span><p class="v3-muted">' + esc(t.userName || '') + ' • ' + esc(TY[t.type] || t.type) + ' • ' + esc(msOf(t.createdAt) ? dt(msOf(t.createdAt)) : '') + '</p><p class="ticket-desc">' + esc(t.description) + '</p>' +
          (t.imageUrl ? '<button type="button" class="ud-pic tk-pic" data-viewer="' + esc(t.imageUrl) + '" data-caption="' + esc(t.title) + '"><img src="' + esc(t.imageUrl) + '" alt="" loading="lazy"></button>' : '') +
          '<textarea class="tk-reply" rows="2" maxlength="1000" placeholder="رد على صاحب البلاغ…">' + esc(t.adminReply || '') + '</textarea><div class="v5-row"><select class="tk-status"><option value="new">جديد</option><option value="in_progress">قيد المعالجة</option><option value="resolved">تم الحل</option></select><button type="button" class="v3-btn tk-save">حفظ</button></div></div></div>';
      }).join('') : '<p class="v3-muted">لا توجد بلاغات.</p>';
      box.querySelectorAll('.tk-row').forEach(function (row) {
        var id = row.getAttribute('data-id'), t = arr.filter(function (x) { return x.id === id; })[0]; row.querySelector('.tk-status').value = t.status;
        row.querySelector('.tk-save').addEventListener('click', function () {
          var st = row.querySelector('.tk-status').value, rep = row.querySelector('.tk-reply').value.trim().slice(0, 1000);
          var d = { status: st, adminReply: rep, updatedAt: ts() }; if (rep) { d.repliedAt = ts(); d.repliedBy = String(nameOf(me().data)).slice(0, 80); }
          db.collection('supportTickets').doc(id).update(d).then(function () { V7.log('support_update', 'ticket', id, t.title, ST[st]); say('tkAdminMsg', 'تم تحديث البلاغ.', true); loadTicketsAdmin(); })
            .catch(function (e) { say('tkAdminMsg', errTxt(e, 'تحديث البلاغ')); });
        });
      });
    }).catch(function (e) { say('tkAdminMsg', errTxt(e, 'تحميل البلاغات')); });
  }

  /* =========================================================
     5) النسخ الاحتياطي (واجهة لـ Cloud Functions؛ لا تعمل قبل نشرها)
     ========================================================= */
  function callFn(name, data) {
    if (!firebase.functions) return Promise.reject(Object.assign(new Error('Cloud Functions غير محمّلة'), { code: 'functions/unavailable' }));
    return firebase.functions().httpsCallable(name)(data || {});
  }
  function fnErr(er) { var c = er && er.code || ''; return (c === 'functions/not-found' || c === 'functions/unavailable') ? 'وظائف النسخ الاحتياطي غير منشورة بعد (انظر functions/README_AR.md).' : ('تعذّرت العملية: ' + ((er && er.message) || c)); }
  function loadBackups() {
    if (!isAdmin()) { say('bkMsg', 'هذه الصفحة للأدمن فقط.'); return; }
    db.collection('backups').get().then(function (snap) {
      var arr = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; arr.push(x); }); arr.sort(function (a, b) { return (msOf(b.createdAt) || 0) - (msOf(a.createdAt) || 0); });
      $('bkList').innerHTML = arr.length ? arr.map(function (b) {
        return '<div class="v3-admin-row" data-id="' + esc(b.id) + '"><div class="v3-admin-info"><strong>' + esc(msOf(b.createdAt) ? dt(msOf(b.createdAt)) : b.id) + '</strong> <span class="v3-chip on">' + esc(b.sizeKB || '?') + ' KB</span><p class="v3-muted">' + esc((b.collections || []).join('، ')) + ' • بصمة: <code dir="ltr">' + esc(String(b.sha256 || '').slice(0, 12)) + '</code></p></div><div class="v3-admin-btns"><button type="button" data-a="dl">تنزيل</button><button type="button" data-a="rs" class="danger">استعادة</button></div></div>';
      }).join('') : '<p class="v3-muted">لا توجد نسخ احتياطية بعد.</p>';
      $('bkList').querySelectorAll('.v3-admin-row').forEach(function (row) {
        var id = row.getAttribute('data-id');
        row.querySelector('[data-a=dl]').addEventListener('click', function () { callFn('getBackupDownloadUrl', { id: id }).then(function (r) { V7.log('backup_download', 'backup', id, id, 'ok'); window.open(r.data.url, '_blank', 'noopener'); }).catch(function (e) { say('bkMsg', fnErr(e)); }); });
        row.querySelector('[data-a=rs]').addEventListener('click', function () {
          var w = window.prompt('الاستعادة تدمج بيانات النسخة في قاعدة البيانات الحالية (دون حذف) وتُنشئ نسخة أمان قبل التنفيذ.\nللتأكيد اكتب كلمة: استعادة');
          if (w !== 'استعادة') return;
          say('bkMsg', 'جاري التحقق من النسخة والاستعادة…', true);
          callFn('restoreBackup', { id: id }).then(function (r) { V7.log('backup_restore', 'backup', id, id, 'ok'); say('bkMsg', 'تمت الاستعادة بعد التحقق من سلامة النسخة (' + ((r.data && r.data.restored) || '?') + ' وثيقة).', true); loadBackups(); }).catch(function (e) { V7.log('backup_restore', 'backup', id, id, 'فشل'); say('bkMsg', fnErr(e)); });
        });
      });
    }).catch(function (e) { say('bkMsg', errTxt(e, 'تحميل النسخ')); });
  }
  function initBackups() {
    var c = $('bkCreate'); if (c) c.addEventListener('click', function () { c.disabled = true; say('bkMsg', 'جاري إنشاء النسخة…', true); callFn('createBackup', {}).then(function (r) { V7.log('backup_create', 'backup', (r.data && r.data.id) || '', 'يدوي', 'ok'); say('bkMsg', 'تم إنشاء النسخة.', true); loadBackups(); }).catch(function (e) { V7.log('backup_create', 'backup', '', 'يدوي', 'فشل'); say('bkMsg', fnErr(e)); }).then(function () { c.disabled = false; }); });
    var r = $('bkReload'); if (r) r.addEventListener('click', loadBackups);
    var l = $('logsReload'); if (l) l.addEventListener('click', loadLogs);
    document.querySelectorAll('#tkCats .acc-cat').forEach(function (b) { b.addEventListener('click', function () { tkFilter = b.getAttribute('data-st'); document.querySelectorAll('#tkCats .acc-cat').forEach(function (x) { x.classList.toggle('on', x === b); }); loadTicketsAdmin(); }); });
  }

  /* =========================================================
     6) البحث الشامل (محتوى عام فقط؛ بلا بيانات خاصة)
     ========================================================= */
  function stripHtml(s) { return String(s || '').replace(/<[^>]*>/g, ' '); }
  function doSearch(q) {
    var out = $('searchResults'); var nq = norm(q);
    if (nq.length < 2) { out.innerHTML = '<p class="v3-muted">اكتب كلمتين على الأقل للبحث.</p>'; return; }
    var toks = nq.split(/\s+/), res = [];
    function match(txt) { var n = norm(stripHtml(txt)); return toks.every(function (t) { return n.indexOf(t) !== -1; }); }
    var news = (typeof latestNewsItems !== 'undefined' && latestNewsItems) || [];
    news.forEach(function (it) { var d = it.data || {}; if (match((d.title || '') + ' ' + (d.content || ''))) res.push({ t: 'خبر / إعلان', title: d.title, sub: (d.content || '').slice(0, 110), open: function () { showPage('latest-news-page'); openNewsDetail(it.id); } }); });
    if (window.V3 && V3.activitiesData) V3.activitiesData().forEach(function (a) { if (match((a.title || '') + ' ' + (a.description || '') + ' ' + (a.location || ''))) res.push({ t: ((a.startAt && a.startAt.toMillis && a.startAt.toMillis() >= Date.now()) ? 'برنامج قادم' : 'برنامج سابق'), title: a.title, sub: (a.description || a.location || '').slice(0, 110), open: function () { V3.openActivityDetail(a.id); } }); });
    if (window.V3 && V3.unitsData) V3.unitsData().forEach(function (u) { if (match((u.name || '') + ' ' + (u.description || ''))) res.push({ t: 'وحدة', title: u.name, sub: (u.description || '').slice(0, 110), open: function () { V3.openUnitDetail(u.id); } }); });
    out.innerHTML = res.length ? res.slice(0, 60).map(function (r, i) { return '<button type="button" class="sr-item" data-i="' + i + '"><span class="sr-type">' + esc(r.t) + '</span><strong>' + esc(r.title) + '</strong><span class="sr-sub">' + esc(r.sub) + '</span></button>'; }).join('') : '<p class="v3-muted">لا توجد نتائج مطابقة.</p>';
    out.querySelectorAll('.sr-item').forEach(function (b) { b.addEventListener('click', function () { res[Number(b.getAttribute('data-i'))].open(); }); });
  }
  function initSearch() {
    var sb = $('searchBtn'); if (sb) sb.addEventListener('click', function () { showPage('search-page'); setTimeout(function () { var i = $('searchInput'); if (i) i.focus(); }, 300); });
    var f = $('searchForm'); if (f) f.addEventListener('submit', function (e) { e.preventDefault(); doSearch($('searchInput').value); });
  }

  /* =========================================================
     7) التعليقات: ردود + إعجاب عادي + إعجاب رسمي (قائد الفوج) + تفاعلات + حفظ
     ========================================================= */
  function postRef(id) { return db.collection('announcements').doc(id); }
  function loadThread(id) {
    var ref = postRef(id), m = me();
    return Promise.all([ref.collection('reactions').get(), ref.collection('saves').get(), ref.collection('comments').where('hidden', '==', false).get()]).then(function (r) {
      var counts = {}, mine = null, total = 0, comments = [];
      r[0].forEach(function (d) { var x = d.data(); counts[x.type] = (counts[x.type] || 0) + 1; total++; if (m.uid && d.id === m.uid) mine = x.type; });
      var saved = false; r[1].forEach(function (d) { if (m.uid && d.id === m.uid) saved = true; });
      r[2].forEach(function (d) { var x = d.data(); x.id = d.id; comments.push(x); });
      return Promise.all(comments.map(function (c) {
        var cr = ref.collection('comments').doc(c.id);
        return Promise.all([cr.collection('likes').get().catch(function () { return { size: 0, forEach: function () {} }; }), cr.collection('officialLike').get().catch(function () { return { empty: true, forEach: function () {} }; })]).then(function (x) {
          c.likes = x[0].size; c.liked = false; x[0].forEach(function (d) { if (m.uid && d.id === m.uid) c.liked = true; });
          c.official = null; x[1].forEach(function (d) { c.official = d.data(); });
        });
      })).then(function () { return { counts: counts, mine: mine, total: total, saved: saved, saves: r[1].size, comments: comments }; });
    });
  }
  function commentHtml(c, replies, isReply) {
    var m = me(), mineC = m.uid && c.uid === m.uid;
    var off = c.official ? '<div class="cm-official" title="إعجاب رسمي"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i>' + (c.official.photoURL ? '<img src="' + esc(c.official.photoURL) + '" alt="" onerror="this.remove()">' : '') + '<span><b>إعجاب رسمي</b> من ' + esc(c.official.name) + ' — ' + esc(c.official.roleLabel) + '</span></div>' : '';
    return '<li class="cm-item' + (isReply ? ' cm-reply' : '') + '" data-cid="' + esc(c.id) + '"><div class="cm-head"><strong>' + esc(c.authorName || 'عضو') + '</strong><time>' + esc(msOf(c.createdAt) ? H().fmtD(msOf(c.createdAt)) : '') + '</time></div><p>' + esc(c.text) + '</p>' + off +
      '<div class="cm-tools"><button type="button" class="cm-like' + (c.liked ? ' on' : '') + '" data-like="' + esc(c.id) + '" aria-pressed="' + !!c.liked + '"><i class="fa-solid fa-thumbs-up" aria-hidden="true"></i> <span>' + (c.likes || 0) + '</span></button>' +
      (!isReply ? '<button type="button" class="cm-reply-btn" data-reply="' + esc(c.id) + '">رد</button>' : '') +
      (isAdmin() ? '<button type="button" class="cm-off' + (c.official ? ' on' : '') + '" data-official="' + esc(c.id) + '">' + (c.official ? 'إلغاء الإعجاب الرسمي' : 'إعجاب رسمي') + '</button>' : '') +
      ((mineC || isAdmin()) ? '<button type="button" class="cm-del" data-del="' + esc(c.id) + '">حذف</button>' : '') + '</div>' +
      (replies && replies.length ? '<ul class="cm-replies">' + replies.map(function (r) { return commentHtml(r, null, true); }).join('') + '</ul>' : '') + '<div class="cm-replybox" data-for="' + esc(c.id) + '" hidden></div></li>';
  }
  window.SEPost = { mount: function (host, opt) {
    if (!host) return; var id = opt.id, Hh = H();
    host.innerHTML = '<p class="v3-muted"><i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> جاري تحميل التفاعلات...</p>';
    function guard() {
      var m = me();
      if (!m.uid) { Hh.notify('سجّل الدخول للتفاعل مع المنشورات.', 'warning'); try { closeModal('newsDetailModal'); } catch (e) {} openModal('roleSelectionModal'); return false; }
      if (!Hh.active()) { Hh.notify('حسابك قيد المراجعة أو غير نشط؛ لا يمكنك التفاعل بعد.', 'warning'); return false; }
      return true;
    }
    function render(s) {
      var tops = s.comments.filter(function (c) { return !c.parentId; }).sort(function (a, b) { return (msOf(b.createdAt) || 0) - (msOf(a.createdAt) || 0); });
      function repliesOf(c) { return s.comments.filter(function (x) { return x.parentId === c.id; }).sort(function (a, b) { return (msOf(a.createdAt) || 0) - (msOf(b.createdAt) || 0); }); }
      var rx = Hh.REACTIONS.map(function (r) { var c = s.counts[r.type] || 0, on = s.mine === r.type; return '<button type="button" class="rx-btn' + (on ? ' on' : '') + '" data-rx="' + r.type + '" aria-pressed="' + on + '" title="' + esc(r.label) + '" aria-label="' + esc(r.label) + ': ' + c + '">' + Hh.rIcon(r) + '<span class="rx-n">' + c + '</span></button>'; }).join('');
      host.innerHTML = '<div class="rx-total" aria-live="polite">' + s.total + ' تفاعل • ' + s.comments.length + ' تعليق • ' + s.saves + ' حفظ</div><div class="rx-bar" role="group" aria-label="التفاعلات">' + rx +
        '<button type="button" class="rx-btn rx-save' + (s.saved ? ' on' : '') + '" data-save="1" aria-pressed="' + s.saved + '" title="حفظ المنشور"><svg class="rx-ico" viewBox="0 0 24 24" aria-hidden="true" fill="' + (s.saved ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.8"><path d="M6 3h12v18l-6-4-6 4z"/></svg><span class="rx-n">' + s.saves + '</span></button></div>' +
        '<div class="cm-wrap"><h4 class="v3-sub-title">التعليقات (' + s.comments.length + ')</h4>' +
        (me().uid ? '<form class="cm-form" data-parent="" novalidate><textarea maxlength="500" rows="2" placeholder="اكتب تعليقك..." aria-label="تعليق"></textarea><div class="cm-actions"><span class="cm-count">0/500</span><button type="submit" class="v3-btn">نشر التعليق</button></div><p class="v5-msg cm-msg" role="status"></p></form>' : '<p class="v3-muted">سجّل الدخول لإضافة تعليق.</p>') +
        '<ul class="cm-list">' + (tops.map(function (c) { return commentHtml(c, repliesOf(c), false); }).join('') || '<li class="v3-muted">لا توجد تعليقات بعد.</li>') + '</ul></div>';
      bind(s);
    }
    function refresh() { return loadThread(id).then(render).catch(function (e) { host.innerHTML = '<p class="v5-msg bad">تعذّر تحميل التفاعلات (' + esc(e && e.code || 'خطأ') + ').</p>'; }); }
    function postComment(form, parentId) {
      var ta = form.querySelector('textarea'), msg = form.querySelector('.cm-msg'), t = ta.value.trim(), prob = Hh.commentProblem(t);
      if (prob) { msg.textContent = prob; msg.classList.add('bad'); return; }
      if (!guard()) return;
      var btn = form.querySelector('button[type=submit]'); btn.disabled = true;
      var d = me().data, name = nameOf(d); if (d.prefs && d.prefs.commentName === 'first') name = String(name).trim().split(/\s+/)[0] || 'عضو';
      var doc = { uid: me().uid, authorName: String(name).slice(0, 80), text: t, createdAt: ts(), hidden: false }; if (parentId) doc.parentId = parentId;
      postRef(id).collection('comments').add(doc).then(refresh).catch(function (er) { msg.textContent = 'تعذّر النشر (' + (er && er.code || 'خطأ') + ').'; msg.classList.add('bad'); btn.disabled = false; });
    }
    function bind(s) {
      host.querySelectorAll('[data-rx]').forEach(function (b) { b.addEventListener('click', function () { if (!guard()) return; var t = b.getAttribute('data-rx'), ref = postRef(id).collection('reactions').doc(me().uid); b.disabled = true; (s.mine === t ? ref.delete() : ref.set({ uid: me().uid, type: t, createdAt: ts() })).then(refresh).catch(function (e) { Hh.notify('تعذّر تسجيل التفاعل: ' + (e && e.code || ''), 'error'); b.disabled = false; }); }); });
      var sv = host.querySelector('[data-save]');
      if (sv) sv.addEventListener('click', function () { if (!guard()) return; sv.disabled = true; var bt = db.batch(), a = postRef(id).collection('saves').doc(me().uid), u = db.collection('users').doc(me().uid).collection('saved').doc(id); if (s.saved) { bt.delete(a); bt.delete(u); } else { bt.set(a, { uid: me().uid, savedAt: ts() }); bt.set(u, { postId: id, savedAt: ts() }); } bt.commit().then(function () { return refresh(); }).catch(function (e) { Hh.notify('تعذّر الحفظ: ' + (e && e.code || ''), 'error'); sv.disabled = false; }); });
      var form = host.querySelector('.cm-form');
      if (form) { var ta = form.querySelector('textarea'), cnt = form.querySelector('.cm-count'); ta.addEventListener('input', function () { cnt.textContent = ta.value.length + '/500'; }); form.addEventListener('submit', function (e) { e.preventDefault(); postComment(form, ''); }); }
      host.querySelectorAll('[data-reply]').forEach(function (b) { b.addEventListener('click', function () {
        if (!guard()) return; var cid = b.getAttribute('data-reply'), box = host.querySelector('.cm-replybox[data-for="' + cid + '"]');
        box.hidden = !box.hidden; if (!box.hidden && !box.firstChild) { box.innerHTML = '<form class="cm-form" novalidate><textarea maxlength="500" rows="2" placeholder="اكتب ردك..." aria-label="رد"></textarea><div class="cm-actions"><button type="submit" class="v3-btn">نشر الرد</button></div><p class="v5-msg cm-msg" role="status"></p></form>'; box.querySelector('form').addEventListener('submit', function (e) { e.preventDefault(); postComment(box.querySelector('form'), cid); }); }
      }); });
      host.querySelectorAll('[data-like]').forEach(function (b) { b.addEventListener('click', function () {
        if (!guard()) return; var cid = b.getAttribute('data-like'), c = s.comments.filter(function (x) { return x.id === cid; })[0], ref = postRef(id).collection('comments').doc(cid).collection('likes').doc(me().uid); b.disabled = true;
        (c.liked ? ref.delete() : ref.set({ uid: me().uid, createdAt: ts() })).then(refresh).catch(function (e) { Hh.notify('تعذّر الإعجاب: ' + (e && e.code || ''), 'error'); b.disabled = false; });
      }); });
      host.querySelectorAll('[data-official]').forEach(function (b) { b.addEventListener('click', function () {
        if (!isAdmin()) return; var cid = b.getAttribute('data-official'), c = s.comments.filter(function (x) { return x.id === cid; })[0], ref = postRef(id).collection('comments').doc(cid).collection('officialLike').doc('leader'); b.disabled = true;
        var m = me(), d = m.data;
        var p = c.official ? ref.delete().then(function () { return V7.log('official_like_remove', 'comment', cid, c.authorName, 'ok'); })
          : ref.set({ uid: m.uid, name: String(nameOf(d)).slice(0, 80), roleLabel: 'قائد الفوج', photoURL: (d.photoURL && typeof safeImgUrl === 'function' ? safeImgUrl(d.photoURL) : '') || '', createdAt: ts() }).then(function () {
            V7.log('official_like', 'comment', cid, c.authorName, 'ok');
            if (c.uid && c.uid !== m.uid) return db.collection('users').doc(c.uid).collection('inbox').add({ type: 'official_like', title: 'إعجاب رسمي من قائد الفوج', body: 'أعجب قائد الفوج بتعليقك: «' + String(c.text).slice(0, 80) + '»', issuer: 'قائد الفوج', issuerName: nameOf(d), link: 'latest-news-page', createdAt: ts() }).catch(function () {});
          });
        p.then(refresh).catch(function (e) { Hh.notify('تعذّر تنفيذ الإعجاب الرسمي: ' + (e && e.code || ''), 'error'); b.disabled = false; });
      }); });
      host.querySelectorAll('[data-del]').forEach(function (b) { b.addEventListener('click', function () {
        if (!window.confirm('حذف هذا التعليق؟')) return; var cid = b.getAttribute('data-del'), c = s.comments.filter(function (x) { return x.id === cid; })[0];
        var bt = db.batch(); bt.delete(postRef(id).collection('comments').doc(cid));
        if (isAdmin()) s.comments.filter(function (x) { return x.parentId === cid; }).forEach(function (r) { bt.delete(postRef(id).collection('comments').doc(r.id)); });
        bt.commit().then(function () { if (isAdmin() && c.uid !== me().uid) V7.log('comment_delete', 'comment', cid, c.authorName, 'ok'); return refresh(); }).catch(function (e) { Hh.notify('تعذّر الحذف: ' + (e && e.code || ''), 'error'); });
      }); });
    }
    return refresh();
  } };

  /* =========================================================
     8) وحدات: قائد الوحدة يدير وحدته فقط (زر في صفحة الوحدة)
     ========================================================= */
  function wrapUnitPage() {
    if (!window.V3 || !V3.openUnitDetail || V3.openUnitDetail.__v7) return;
    var orig = V3.openUnitDetail;
    V3.openUnitDetail = function (id, noPush) {
      orig(id, noPush);
      var m = me(); var body = $('unitDetailBody'); if (!body) return;
      var d = m.data; if (d && d.role === 'leader' && d.accountStatus === 'active' && d.unitId === id && !body.querySelector('.ud-manage')) {
        var b = document.createElement('div'); b.className = 'btn-row ud-manage'; b.innerHTML = '<button type="button" class="glow-btn btn-green hover-lift"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> إدارة وحدتي</button>';
        b.querySelector('button').addEventListener('click', function () { V3.openUnitForm(id); }); body.insertBefore(b, body.firstChild);
      }
    };
    V3.openUnitDetail.__v7 = true;
  }

  /* =========================================================
     التهيئة
     ========================================================= */
  window.addEventListener('se:tab', function (e) {
    var t = e.detail; if (t === 'accounts-tab') loadAccounts(); else if (t === 'approvals-tab') loadApprovals(); else if (t === 'logs-tab') loadLogs(); else if (t === 'support-admin-tab') loadTicketsAdmin(); else if (t === 'backups-tab') loadBackups();
  });
  // تسجيل العمليات الإدارية القديمة (دون تغيير سلوكها)
  function wrapLegacy() {
    function wrap(name, fn) { var o = window[name]; if (typeof o !== 'function' || o.__v7) return; var w = function () { try { fn.apply(null, arguments); } catch (e) { console.warn(e); } return o.apply(this, arguments); }; w.__v7 = true; window[name] = w; }
    wrap('saveLeaderPermissions', function () { if (typeof pendingEditPermissionsUid !== 'undefined' && pendingEditPermissionsUid) V7.log('role_change', 'user', pendingEditPermissionsUid, 'تعديل صلاحيات', 'ok'); });
    wrap('executeDeleteAnnouncement', function () { if (typeof pendingDeleteAnnouncementId !== 'undefined' && pendingDeleteAnnouncementId) V7.log('announcement_delete', 'announcement', pendingDeleteAnnouncementId, 'حذف', 'ok'); });
    wrap('approveLeaderVerification', function (uid) { V7.log('approve_request', 'user', uid, 'قائد/إعلام', 'ok'); inboxFor(uid, 'تمت الموافقة على طلبك', 'وافق قائد الفوج على اعتماد حسابك. يمكنك الآن استخدام صلاحيات حسابك.', '').catch(function () {}); });
    wrap('rejectLeaderVerification', function (uid) { V7.log('reject_request', 'user', uid, 'قائد/إعلام', 'ok'); inboxFor(uid, 'تم رفض طلبك', 'تعذّرت الموافقة على طلب اعتماد حسابك. للاستفسار راسل الدعم الفني.', '').catch(function () {}); });
  }
  function init() {
    wrapLegacy(); initEmail(); initTickets(); initBackups(); initSearch(); wrapUnitPage();
    document.querySelectorAll('.set-row[data-sec="support"]').forEach(function (b) { b.addEventListener('click', function () { setTimeout(loadMyTickets, 100); }); });
    auth.onAuthStateChanged(function () { loggedLogin = false; setTimeout(function () { var m = me(); if (isAdmin() && !loggedLogin) { loggedLogin = true; V7.log('admin_login', 'session', m.uid, nameOf(m.data), 'ok'); } }, 1800); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
