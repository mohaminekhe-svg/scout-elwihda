from h5 import *
with sync_playwright() as p:
    b=p.chromium.launch(); ctx,pg,errs,st=go(b,'admin1',vp=(375,520)); close_notice(pg)
    ev(pg,"openAnnouncementModal('add')"); pg.wait_for_timeout(600)
    print(ev(pg,"""(()=>{const m=document.getElementById('adminAnnouncementModal');
      const sub=m.querySelector('button[type=submit]'); const chain=[];let e=sub;while(e&&e!==document.body){const cs=getComputedStyle(e);chain.push([e.tagName+'.'+(e.className||'').toString().slice(0,30),cs.overflowY,e.scrollHeight,e.clientHeight,cs.position]);e=e.parentElement}
      chain.slice(0,8).forEach(x=>{}); 
      const btns=[...m.querySelectorAll('button,a,input,select,textarea')].filter(b=>b.offsetParent!==null);
      const last=btns[btns.length-1];
      return {chain:chain.slice(0,8), last:last.tagName+'#'+last.id+'.'+last.className+' type='+last.type, lastRect:last.getBoundingClientRect().top}})()"""))
    b.close()
