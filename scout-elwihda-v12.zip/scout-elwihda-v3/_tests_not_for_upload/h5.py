import json, re
from playwright.sync_api import sync_playwright
ROOT='http://127.0.0.1:8765/index.html'
MOCK=open('mock2.js',encoding='utf-8').read()
SEED_JS = r"""
window.__SEED=function(DB,ts){
  var n=Date.now(),D=86400000;
  function U(id,o){DB['users/'+id]=Object.assign({uid:id,accountStatus:'active',email:id+'@x.dz'},o)}
  U('admin1',{role:'admin',fullName:'مدير الموقع'});
  U('lead1',{role:'leader',fullName:'قائد الوحدة',unitId:'u1',unit:'وحدة الكشاف ألف'});
  U('sc1',{role:'scout',fullName:'كشاف أول',unitId:'u1',unit:'وحدة الكشاف ألف',scoutPhone:'0550123456'});
  U('sc2',{role:'scout',fullName:'كشاف معلق',accountStatus:'pending_verification',unitId:'u1',unit:'وحدة الكشاف ألف'});
  U('sc3',{role:'scout',fullName:'كشاف ثالث',unitId:'u2',unit:'عشيرة الجوالة'});
  U('lead2',{role:'leader',accountStatus:'pending_verification',fullName:'قائد معلق',leaderRoleTitle:'قائد وحدة',unitId:'u1',unit:'وحدة الكشاف ألف',createdAt:ts(n-2*D)});
  U('media1',{role:'leader',accountStatus:'pending_verification',fullName:'إعلامي معلق',leaderRoleTitle:'مسؤول إعلام',createdAt:ts(n-D)});
  U('rej1',{role:'leader',accountStatus:'rejected',fullName:'قائد مرفوض',leaderRoleTitle:'قائد وحدة'});
  U('par1',{role:'parent',fullName:'ولي أمر',parentPhone:'0770000000'});
  DB['users/sc1'].birthDate='2012-05-14'; DB['users/sc1'].bloodType='O+'; DB['users/sc1'].nickname='النسر';
  DB['leaders/lead2']={uid:'lead2',role:'leader',accountStatus:'pending_verification'}; DB['leaders/media1']={uid:'media1',role:'leader',accountStatus:'pending_verification'};
  DB['backups/2026-11-01T10-00-00-000Z']={createdAt:ts(n-5*D),sizeKB:120,sha256:'abcdef1234567890',collections:['users','units']};
  DB['units/u1']={name:'وحدة الكشاف ألف',description:'وصف الوحدة',status:'active',order:1,pub:{leaders:[{name:'القائد المنشور'},{},{}]},publishNames:true};
  DB['units/u2']={name:'عشيرة الجوالة',status:'active',order:2,pub:{}};
  DB['units/u3']={name:'وحدة مؤرشفة',status:'archived',order:3,pub:{}};
  DB['unitPrivate/u1']={leaders:[{name:'قائد 1',phone:'0550000001',email:'l1@x.dz'},{name:'قائد 2',phone:'0550000002',email:'l2@x.dz'},{name:'قائد 3',phone:'',email:''}]};
  DB['announcements/n1']={title:'خبر رحلة',content:'تفاصيل الخبر الأول',category:'trips',published:true,createdAt:ts(n-1000),driveFileId:'abcdefghijklmnopqrstuvwxyz0123456'};
  DB['announcements/n2']={title:'خبر عام',content:'تفاصيل الخبر الثاني',category:'',published:true,createdAt:ts(n-5000)};
  DB['announcements/n3']={title:'مسودة',content:'x',published:false,createdAt:ts(n)};
  DB['announcements/n4']={title:'خبر منتهٍ',content:'x',published:true,createdAt:ts(n-9*D),startAt:ts(n-9*D),endAt:ts(n-D)};
  DB['announcements/n5']={title:'خبر مجدول',content:'x',published:true,createdAt:ts(n),startAt:ts(n+5*D),endAt:null};
  DB['activities/a1']={title:'تجمع قادم',description:'وصف',kind:'gathering',unitId:'u1',startAt:ts(n+3*D),location:'الحميز',status:'published'};
  DB['activities/a2']={title:'نشاط سابق',kind:'camp',unitId:'u1',startAt:ts(n-5*D),status:'published',imageUrl:'https://drive.google.com/thumbnail?id=abcdefghijklmnopqrstuvwxyz0123456&sz=w800',driveFileId:'abcdefghijklmnopqrstuvwxyz0123456'};
  DB['activities/a3']={title:'مسودة نشاط',kind:'trip',startAt:ts(n+9*D),status:'draft'};
  DB['siteNotifications/nt1']={title:'فتح التسجيلات',body:'ندعوكم للتسجيل في الموسم الجديد',issuer:'قائد الفوج',issuerName:'الأستاذ فلان',startAt:ts(n-D),endAt:ts(n+D),closeDelaySec:3,audience:'all',published:true};
  DB['siteNotifications/nt2']={title:'منتهٍ',body:'x',issuer:'جهة إدارية',issuerName:'ز',startAt:ts(n-3*D),endAt:ts(n-2*D),closeDelaySec:0,audience:'all',published:true};
  DB['siteNotifications/nt3']={title:'مخفي',body:'x',issuer:'جهة إدارية',issuerName:'ز',startAt:ts(n-D),endAt:null,closeDelaySec:0,audience:'all',published:false};
  DB['siteNotifications/nt4']={title:'للأعضاء فقط',body:'x',issuer:'مسؤول الإعلام',issuerName:'م',startAt:ts(n-D),endAt:null,closeDelaySec:0,audience:'members',published:true};
  DB['settings/googleDrive']={webAppUrl:'https://script.google.com/macros/s/TESTID/exec'};
  window.__EMAIL2UID={'admin1@x.dz':'admin1','sc1@x.dz':'sc1','ghost@x.dz':'ghost','badrole@x.dz':'badrole'}; DB['users/badrole']={uid:'badrole',role:'Admin',accountStatus:'active',email:'badrole@x.dz'};
};
"""
def new_page(p_browser, uid=None, vp=(1280,800), extra_seed='', reduced=False):
    ctx=p_browser.new_context(viewport={'width':vp[0],'height':vp[1]}, reduced_motion='reduce' if reduced else 'no-preference')
    pg=ctx.new_page()
    pre=SEED_JS+extra_seed+(("window.__LOGIN_UID=%s;"%json.dumps(uid)) if uid else '')
    pg.add_init_script(pre)
    pg.route('**/*gstatic.com/**',lambda r: r.fulfill(body=MOCK if 'app-compat' in r.request.url else '',content_type='application/javascript'))
    pg.route('**/*googleapis.com/**',lambda r: r.fulfill(body='',content_type='text/css'))
    pg.route('**/*cdnjs.cloudflare.com/**',lambda r: r.fulfill(body='',content_type='text/css' if r.request.url.endswith('.css') else 'application/javascript'))
    state={'uploads':[]}
    def script_route(route):
        req=route.request
        if req.method=='POST':
            body=json.loads(req.post_data or '{}'); state['uploads'].append(body)
            if state.get('fail'): return route.fulfill(body='<html>oops</html>',content_type='text/html')
            fid='UP'+str(len(state['uploads'])).zfill(2)+'abcdefghijklmnopqrstuvw'
            return route.fulfill(body=json.dumps({'ok':True,'fileId':fid}),content_type='application/json',headers={'access-control-allow-origin':'*'})
        route.fulfill(body='{}',content_type='application/json',headers={'access-control-allow-origin':'*'})
    pg.route('https://script.google.com/**',script_route)
    pg.route('**/*drive.google.com/**',lambda r: r.fulfill(status=200,content_type='image/png',body=open('t_sq.webp','rb').read()))
    pg.route('**/*googleusercontent.com/**',lambda r: r.fulfill(status=200,content_type='image/png',body=open('t_sq.webp','rb').read()))
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    return ctx,pg,errs,state
def wait_intro(pg):
    pg.wait_for_function("getComputedStyle(document.getElementById('splashScreen')).display==='none'",timeout=15000)
def ev(pg,js): return pg.evaluate(js)
res=[]
def chk(n,c,extra=''):
    res.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+(' '+str(extra) if (extra and not c) else ''))
def summary():
    bad=[n for n,c in res if not c]; print('\nTOTAL',len(res),'PASS',len(res)-len(bad),'FAIL',len(bad)); 
    if bad: print(bad)

# ---------- مساعدات مشتركة ----------
def close_notice(pg):
    try:
        for _ in range(5):
            if not pg.query_selector('.se-notice-close'): break
            pg.wait_for_function("(()=>{const b=document.querySelector('.se-notice-close');return !b||!b.disabled})()",timeout=8000)
            if pg.query_selector('.se-notice-close'): pg.click('.se-notice-close')
            pg.wait_for_timeout(250)
    except Exception: pass
def go(b,uid=None,vp=(1280,800),**kw):
    ctx,pg,errs,st=new_page(b,uid,vp,**kw); pg.goto(ROOT); wait_intro(pg); pg.wait_for_timeout(700); return ctx,pg,errs,st
def openmenu(pg):
    pg.click('#sidebarToggle'); pg.wait_for_timeout(450)
def nav(pg,page):
    openmenu(pg); pg.click(f'#navMenu .nav-group-btn[data-page="{page}"]'); pg.wait_for_timeout(500)
    if pg.evaluate("document.getElementById('navMenu').classList.contains('active')"):
        pg.mouse.click(40,500); pg.wait_for_timeout(450)
def store(pg,path): return pg.evaluate("p=>window.__STORE[p]||null",path)
def keys(pg,prefix): return pg.evaluate("p=>Object.keys(window.__STORE).filter(k=>k.indexOf(p)===0)",prefix)

import json as _json
def persist_seed(pg):
    """نسخة من قاعدة المحاكي الحالية لإعادة تحميل الصفحة مع الاحتفاظ بالبيانات (يحاكي بقاء Firestore)."""
    snap=pg.evaluate("JSON.stringify(window.__STORE)")
    return ("var __s0=window.__SEED; window.__SEED=function(DB,ts){ __s0(DB,ts); var o=JSON.parse(%s,function(k,v){ return (v&&typeof v==='object'&&v.__ts!=null&&v.toMillis===undefined)?ts(v.__ts):v; }); Object.keys(DB).forEach(function(k){delete DB[k]}); Object.assign(DB,o); };" % _json.dumps(snap))

FN_OK = "window.__fnCalls=[]; (function(){ var iv=setInterval(function(){ if(window.firebase){ clearInterval(iv); window.firebase.functions=function(){ return {httpsCallable:function(n){ return function(d){ window.__fnCalls.push([n,d]); if(window.__fnFail){ var e=new Error('not found'); e.code='functions/not-found'; return Promise.reject(e);} return Promise.resolve({data:(n==='getBackupDownloadUrl'?{url:'https://example.com/b.json'}:(n==='restoreBackup'?{restored:7}:(n==='createBackup'?{id:'2026-11-16T10-00-00-000Z'}:{ok:true})))}); }; }}; }; } },5); })();"
