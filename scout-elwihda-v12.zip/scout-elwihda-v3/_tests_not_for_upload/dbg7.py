from h5 import *
with sync_playwright() as p:
    b=p.chromium.launch(); ctx,pg,errs,st=go(b,'admin1',vp=(375,520)); close_notice(pg)
    ev(pg,"setAdminViewActive(true)"); pg.wait_for_timeout(600)
    print(ev(pg,"[...document.querySelectorAll('.admin-sidebar .admin-nav-btn')].map(b=>[b.textContent.trim().slice(0,14),Math.round(b.getBoundingClientRect().height),getComputedStyle(b).minHeight,b.offsetParent!==null])"))
    b.close()
