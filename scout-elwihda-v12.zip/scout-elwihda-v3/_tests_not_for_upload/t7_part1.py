import re
from h5 import *
RULES=open('../firestore.rules',encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    # ----- قواعد (فحوص نصية) -----
    for n,c in [('rules: adminLogs append-only (no update/delete)',"match /adminLogs/{logId}" in RULES and "allow update, delete: if false;" in RULES),
                ('rules: official like only admin',"match /officialLike/{docId}" in RULES and "allow create: if isAdmin() && docId == 'leader'" in RULES),
                ('rules: support tickets owner-read + admin update',"match /supportTickets/{ticketId}" in RULES and "resource.data.uid == request.auth.uid" in RULES and "affectedKeys().hasOnly(['status', 'adminReply'" in RULES),
                ('rules: unit leader scoped to own unit',"function isUnitLeader(unitId)" in RULES and "myUserDoc().get('unitId', '') == unitId" in RULES and "isUnitLeader(unitId)" in RULES),
                ('rules: inbox written only by admin; backups read-only',"match /inbox/{itemId}" in RULES and "allow create: if isAdmin()" in RULES and "match /backups/{backupId}" in RULES and "allow write: if false;" in RULES),
                ('rules: blood type whitelist',"function validBlood(d)" in RULES and "'AB-'" in RULES),
                ('rules: reply parent must be top-level comment',"parentId" in RULES and "!('parentId' in get(" in RULES)]:
        chk(n,c)
    # ----- الفوتر والمقدمة -----
    ctx,pg,errs,st=go(b); close_notice(pg)
    ft=pg.inner_text('.site-footer')
    chk('footer: exact credit text','محمد أمين خرفي — تطوير وتصميم، بإشراف قسم الإعلام' in ft and 'Mohamed Amine Kherfi' not in ft,ft)
    chk('footer compact & centered',ev(pg,"(()=>{const f=document.querySelector('.site-footer');const i=document.querySelector('.footer-inner').getBoundingClientRect();return f.getBoundingClientRect().height<190 && Math.abs((i.left+i.right)/2-innerWidth/2)<4})()"))
    pg.reload(); pg.wait_for_timeout(300)
    bg=ev(pg,"getComputedStyle(document.querySelector('.intro-bg')).backgroundImage")
    chk('intro uses the supplied flag image as background',('intro-bg' in bg) and ev(pg,"fetch('assets/intro/intro-bg.webp').then(r=>r.ok)"),bg)
    ctx.close()
    # ----- تشخيص دخول الأدمن -----
    for email,expect,label in [('ghost@x.dz','لا توجد له وثيقة في users','missing users doc'),('badrole@x.dz','«Admin»','role mismatch')]:
        ctx,pg,errs,st=go(b); close_notice(pg)
        ev(pg,"openModal('adminLoginModal')") if ev(pg,"!!document.getElementById('adminLoginModal')") else None
        pg.fill('#adminEmail',email); pg.fill('#adminPassword','x12345678'); pg.evaluate("document.getElementById('adminLoginForm').requestSubmit()"); pg.wait_for_timeout(1500)
        m=pg.inner_text('#adminError')
        chk(f'admin login ({label}): precise cause + UID + fix instructions',expect in m and ('UID' in m) and ('Firebase Console' in m),m)
        ctx.close()
    # ----- الإعدادات (قائمة رأسية) -----
    ctx,pg,errs,st=go(b,'sc1',extra_seed=FN_OK); close_notice(pg); ERR=errs
    nav(pg,'settings-page')
    rows=ev(pg,"Array.from(document.querySelectorAll('#settingsMenu .set-row')).map(r=>[r.getAttribute('data-sec'),r.innerText.trim()])")
    wanted=['الملف الشخصي','الحساب والأمان','تغيير كلمة المرور','البريد الإلكتروني ورقم الهاتف','الإشعارات','اللغة','الخصوصية','الدعم الفني']
    chk('settings: vertical list with the 8 requested sections in order',[r[1] for r in rows][:8]==wanted,rows)
    chk('settings list is a single column',ev(pg,"(()=>{const x=[...document.querySelectorAll('#settingsMenu .set-row')].map(r=>Math.round(r.getBoundingClientRect().left));return new Set(x).size===1})()"))
    for sec in ['profile','security','password','contact','notifications','language','privacy','support','card','about']:
        pg.click(f'#settingsMenu [data-sec="{sec}"]'); pg.wait_for_timeout(250)
        ok=ev(pg,f"!document.querySelector('.set-panel[data-sec={sec}]').hidden && document.getElementById('settingsMenu').hidden")
        chk(f'sub-page opens: {sec}',ok)
        pg.click(f'.set-panel[data-sec="{sec}"] .set-back'); pg.wait_for_timeout(200)
    # لغات
    pg.click('#settingsMenu [data-sec="language"]'); pg.wait_for_timeout(250)
    lt=pg.inner_text('#langOptions')
    chk('languages: Arabic + Mozabite (قيد التطوير, disabled); no French/English','العربية' in lt and 'المزابية' in lt and 'قيد التطوير' in lt and 'Français' not in lt and 'English' not in lt and ev(pg,"document.querySelector('#langOptions input[value=mzb]').disabled"),lt)
    pg.click('.set-panel[data-sec="language"] .set-back')
    # ملف: فصيلة الدم
    pg.click('#settingsMenu [data-sec="profile"]'); pg.wait_for_timeout(300)
    chk('profile shows stored blood type',pg.input_value('#pfBloodType')=='O+')
    pg.select_option('#pfBloodType','AB-'); pg.click('#profileSaveBtn'); pg.wait_for_timeout(700)
    chk('blood type saved (optional field)',store(pg,'users/sc1')['bloodType']=='AB-')
    pg.select_option('#pfBloodType',''); pg.click('#profileSaveBtn'); pg.wait_for_timeout(600)
    chk('blood type can be cleared',store(pg,'users/sc1')['bloodType']=='')
    pg.select_option('#pfBloodType','O+'); pg.click('#profileSaveBtn'); pg.wait_for_timeout(500)
    pg.click('.set-panel[data-sec="profile"] .set-back')
    # بريد وهاتف
    pg.click('#settingsMenu [data-sec="contact"]'); pg.wait_for_timeout(250)
    chk('contact: email read-only with honest explanation',ev(pg,"document.getElementById('pfEmail').readOnly") and 'غير متاح حاليًا' in pg.inner_text('#pfEmailHint'))
    pg.fill('#pfPhone','0661112233'); pg.click('#contactForm button[type=submit]'); pg.wait_for_timeout(600)
    chk('phone saved from contact section',store(pg,'users/sc1')['scoutPhone']=='0661112233')
    pg.fill('#pfPhone','abc'); pg.click('#contactForm button[type=submit]'); pg.wait_for_timeout(300)
    chk('invalid phone rejected',store(pg,'users/sc1')['scoutPhone']=='0661112233')
    pg.click('.set-panel[data-sec="contact"] .set-back')
    # بطاقة
    pg.click('#settingsMenu [data-sec="card"]'); pg.wait_for_timeout(300)
    c=ev(pg,"(()=>{const c=document.querySelector('.id-card');const r=c.getBoundingClientRect();return {ratio:r.width/r.height,w:r.width,t:c.innerText,round:getComputedStyle(c.querySelector('.avatar-circle')).borderRadius}})()")
    chk('card: horizontal, small, circular photo',1.5<=c['ratio']<=1.7 and c['w']<=541 and c['round']=='50%',c)
    chk('card fields: name+nickname, birth date, unit, blood type',all(x in c['t'] for x in ['كشاف أول','النسر','2012','وحدة الكشاف ألف','O+']),c['t'])
    chk('card no longer shows phone/email','0661112233' not in c['t'] and 'sc1@x.dz' not in c['t'])
    pg.click('.set-panel[data-sec="card"] .set-back')
    # دعم فني (مستخدم)
    pg.click('#settingsMenu [data-sec="support"]'); pg.wait_for_timeout(400)
    pg.fill('#tkTitle','ا'); pg.fill('#tkDesc','وصف'); pg.click('#ticketSubmit'); pg.wait_for_timeout(300)
    chk('ticket: too-short title/description rejected',len(keys(pg,'supportTickets/'))==0)
    pg.select_option('#tkType','upload'); pg.fill('#tkTitle','تعذّر رفع الصورة'); pg.fill('#tkDesc','تظهر رسالة خطأ عند الرفع من الهاتف')
    pg.set_input_files('#tkImageUploader input[type=file]','t_land.jpg'); pg.wait_for_timeout(300)
    pg.click('#ticketSubmit'); pg.wait_for_timeout(1800)
    tk=[store(pg,k) for k in keys(pg,'supportTickets/')]
    chk('ticket created: status=new, own uid, image uploaded via Drive',len(tk)==1 and tk[0]['status']=='new' and tk[0]['uid']=='sc1' and tk[0]['type']=='upload' and tk[0].get('driveFileId','').startswith('UP') and len(st['uploads'])==1,tk)
    chk('my tickets lists it with status «جديد»','تعذّر رفع الصورة' in pg.inner_text('#myTickets') and 'جديد' in pg.inner_text('#myTickets'))
    seed=persist_seed(pg)
    chk('no JS errors in settings flows',not ERR,ERR)
    ctx.close()
    # مستخدم آخر لا يرى بلاغات غيره
    ctx,pg,errs,st=go(b,'sc3',extra_seed=seed+FN_OK); close_notice(pg); nav(pg,'settings-page'); pg.click('#settingsMenu [data-sec="support"]'); pg.wait_for_timeout(600)
    chk("another user doesn't see my tickets",'تعذّر رفع الصورة' not in pg.inner_text('#myTickets'))
    r=ev(pg,"db.collection('supportTickets').get().then(()=>'allowed').catch(e=>e.code)")
    chk('listing all tickets is denied for non-admin',r=='permission-denied',r)
    ctx.close()
    # ----- البحث -----
    ctx,pg,errs,st=go(b); close_notice(pg)
    pg.click('#searchBtn'); pg.wait_for_timeout(500)
    chk('search page opens from header button',ev(pg,"document.getElementById('search-page').classList.contains('active-page')"))
    def q(t):
        pg.fill('#searchInput',t); pg.press('#searchInput','Enter'); pg.wait_for_timeout(300); return pg.inner_text('#searchResults')
    r1=q('رحلة'); chk('search finds published news',('خبر رحلة' in r1))
    chk('search finds units',('وحدة الكشاف ألف' in q('الكشاف ألف')))
    chk('search finds upcoming program',('تجمع قادم' in q('تجمع')))
    r2=q('مسودة'); chk('search never exposes drafts/hidden content','مسودة نشاط' not in r2 and 'مسودة' not in r2.replace('لا توجد نتائج مطابقة.',''),r2)
    chk('search never exposes accounts/emails',('sc1@x.dz' not in q('sc1')) and ('كشاف أول' not in q('كشاف أول')))
    chk('short query asks for more',('كلمتين' in q('ا')))
    pg.fill('#searchInput','خبر عام'); pg.press('#searchInput','Enter'); pg.wait_for_timeout(300); pg.click('#searchResults .sr-item'); pg.wait_for_timeout(700)
    chk('clicking a result opens the item',pg.is_visible('#newsDetailModal'))
    chk('no JS errors on search',not errs,errs)
    ctx.close()
    b.close()
summary()
