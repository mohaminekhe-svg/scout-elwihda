from h5 import *
import datetime
PAGES=['home-page','latest-news-page','next-gathering-page','past-programs-page','bulletin-page','units-page','gallery-page','skills-page','about-page','settings-page']
with sync_playwright() as p:
    b=p.chromium.launch()
    # ============ إدارة الإشعارات (أدمن) ============
    ctx,pg,errs,st=go(b,'admin1'); close_notice(pg)
    ev(pg,"switchAdminTab('notifications-tab')"); pg.wait_for_timeout(600)
    chk('admin notifications list shows all (active/expired/hidden/scheduled)',ev(pg,"document.querySelectorAll('#noticesAdminList .v3-admin-row').length")==4)
    ev(pg,"SENotice.openForm()"); pg.wait_for_timeout(300)
    pg.fill('#ntTitle','موعد الاجتماع'); pg.fill('#ntBody','اجتماع القادة الجمعة'); pg.select_option('#ntIssuer','مسؤول الإعلام'); pg.fill('#ntIssuerName','الأستاذ سمير')
    pg.fill('#ntStart','2026-11-01T08:00'); pg.fill('#ntEnd','2026-11-01T07:00'); pg.fill('#ntDelay','10')
    pg.click('#noticeFormSubmit'); pg.wait_for_timeout(500)
    chk('notice end before start rejected',('بعد' in pg.inner_text('#noticeFormError')) and not [k for k in keys(pg,'siteNotifications/') if store(pg,k)['title']=='موعد الاجتماع'])
    pg.fill('#ntEnd','2026-12-30T20:00'); pg.click('#noticeFormSubmit'); pg.wait_for_timeout(900)
    ks=[k for k in keys(pg,'siteNotifications/') if store(pg,k)['title']=='موعد الاجتماع']
    n=store(pg,ks[0]) if ks else {}
    chk('notice saved with issuer, delay, audience, published',len(ks)==1 and n['issuer']=='مسؤول الإعلام' and n['issuerName']=='الأستاذ سمير' and n['closeDelaySec']==10 and n['published'] is True and n['audience']=='all')
    chk('start/end stored in Algiers time (08:00 → 07:00Z)',datetime.datetime.fromtimestamp(n['startAt']['__ts']/1000,datetime.UTC).strftime('%H:%M')=='07:00')
    nid=ks[0].split('/')[1]
    ev(pg,"window.__DLG=true"); pg.on('dialog',lambda d: d.accept())
    pg.locator(f'#noticesAdminList [data-id="{nid}"] [data-a="toggle"]').evaluate('e=>e.click()'); pg.wait_for_timeout(700)
    chk('hide notice sets published=false',store(pg,ks[0])['published'] is False)
    ctx.close()
    ctx,pg,errs,st=go(b); pg.wait_for_timeout(500)
    seen=[]
    for _ in range(3):
        if pg.query_selector('.se-notice'): seen.append(pg.inner_text('.se-notice'))
        close_notice(pg); pg.wait_for_timeout(300)
    chk('hidden notice not shown to visitors',not any('موعد الاجتماع' in s for s in seen),seen)
    ctx.close()
    # عرض إشعار بدون تأخير: closeDelay 0 ⇒ زر مفعّل مباشرة
    ctx,pg,errs,st=go(b,extra_seed="" ); ctx.close()

    # ============ صفحات المحتوى ============
    ctx,pg,errs,st=go(b); close_notice(pg)
    nt=pg.inner_text('#homePastBox')
    chk('home shows past programs preview (real, with image)','نشاط سابق' in nt and bool(pg.query_selector('#homePastBox img')))
    chk('home next program shows nearest future only','تجمع قادم' in pg.inner_text('#nextActivityBox') and 'مسودة' not in pg.inner_text('#nextActivityBox'))
    openmenu(pg); pg.click('#navMenu .nav-group-btn[data-page="next-gathering-page"]'); pg.wait_for_timeout(300); pg.click('#navMenu .nav-sub-btn[data-page="past-programs-page"]'); pg.wait_for_timeout(500)
    chk('past programs reachable from sidebar submenu',ev(pg,"document.getElementById('past-programs-page').classList.contains('active-page')"))
    chk('past programs page lists past only','نشاط سابق' in pg.inner_text('#recentActivitiesBox') and 'تجمع قادم' not in pg.inner_text('#recentActivitiesBox'))
    nav(pg,'skills-page')
    chk('skills page: coming-soon notice, no fake media',('قريبًا — هذا القسم قيد التطوير' in pg.inner_text('#skills-page')) and ev(pg,"document.querySelectorAll('#skills-page video,#skills-page iframe,#skills-page input').length")==0)
    # الدعم الفني
    ev(pg,"openSupportModal && openSupportModal()") if ev(pg,"typeof openSupportModal")=='function' else ev(pg,"document.getElementById('supportFabBtn')&&document.getElementById('supportFabBtn').click()")
    pg.wait_for_timeout(400)
    chk('support form has name/email/type/description',all(pg.query_selector(s) for s in ['#supportNameInput','#supportEmailInput']) and ev(pg,"SITE_EXTRAS_CONFIG.supportEmail")=='kherfi_mohamed@solution4all.dz')
    ctx.close()

    # ============ تسجيل قائد: قائمة وحدة اختيارية ============
    ctx,pg,errs,st=go(b); close_notice(pg)
    chk('leader registration has optional unit select with units',ev(pg,"document.querySelectorAll('#leaderRegUnit option').length")==3)
    ctx.close()

    # ============ تصميم: عدم وجود تمرير أفقي ============
    for vp,label in [((375,740),'375'),((414,860),'414'),((1280,800),'1280')]:
        ctx,pg,errs,st=go(b,'sc1',vp=vp); close_notice(pg)
        bad=[]
        for pid in PAGES:
            ev(pg,f"showPage('{pid}')"); pg.wait_for_timeout(350)
            if ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth"): bad.append(pid)
        chk(f'{label}px: no horizontal scroll on {len(PAGES)} pages (signed-in)',not bad,bad)
        if label=='375':
            ev(pg,"showPage('latest-news-page')"); pg.wait_for_timeout(500)
            chk('375px: news cards are compact horizontal (not full screen)',ev(pg,"(()=>{const c=document.querySelector('#newsPageGrid .news-card');return c&&getComputedStyle(c).display==='grid'&&c.getBoundingClientRect().height<200})()"))
            openmenu(pg)
            chk('375px: drawer overlays (page not shifted)',ev(pg,"document.querySelector('main.main-content-viewport').getBoundingClientRect().left")==0 and pg.is_visible('#sidebarBackdrop'))
            pg.click('#navMenu .menu-close-btn'); pg.wait_for_timeout(400)
            chk('375px: drawer closes via close button',not ev(pg,"document.getElementById('navMenu').classList.contains('active')"))
        chk(f'{label}px: no JS errors',not errs,errs)
        ctx.close()
    b.close()
summary()
