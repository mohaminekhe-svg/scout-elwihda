import re,os
from h5 import *
EMO=re.compile('[\U0001F300-\U0001FAFF\u2600-\u27BF\u2B50\u2705\u274C\U0001F1E6-\U0001F1FF]')
with sync_playwright() as p:
    b=p.chromium.launch()
    for uid in [None,'sc1','admin1']:
        ctx,pg,errs,st=go(b,uid); close_notice(pg)
        r=ev(pg,"""(()=>{const miss=new Set(),emo=[],img=[];
          document.querySelectorAll('[onclick]').forEach(e=>{const m=(e.getAttribute('onclick')||'').match(/^\\s*(?:return\\s+)?([A-Za-z_$][\\w$.]*)\\s*\\(/); if(m){const path=m[1].split('.');let o=window;for(const k of path){o=o&&o[k]} if(typeof o!=='function') miss.add(m[1])}});
          document.querySelectorAll('button,.nav-btn,a.btn,[role=button]').forEach(e=>{const t=e.textContent; if(/[\\u{1F300}-\\u{1FAFF}\\u2600-\\u27BF\\u2705\\u274C]/u.test(t)) emo.push(e.id||e.className||t.trim().slice(0,20))});
          document.querySelectorAll('img').forEach(i=>{ if(i.src && !i.complete) return; if(i.complete && i.naturalWidth===0 && i.src && !i.src.includes('drive.google')) img.push(i.getAttribute('src'))});
          const ids={};document.querySelectorAll('[id]').forEach(e=>{ids[e.id]=(ids[e.id]||0)+1});const dup=Object.keys(ids).filter(k=>ids[k]>1);
          return {miss:[...miss],emo,img,dup}})()""")
        print(uid,r,'errors:',errs)
        ctx.close()
    b.close()
