import re
from h5 import *
RULES=open('../firestore.rules',encoding='utf-8').read()
def many(n,len_=40):
    return "var _s1=window.__SEED; window.__SEED=function(DB,ts){_s1(DB,ts); var n=Date.now(),D=86400000; for(var i=0;i<%d;i++){DB['siteNotifications/m'+i]={title:'إشعار '+i,body:'نص '+'ن'.repeat(%d),issuer:'مسؤول آخر',issuerName:'م',startAt:ts(n-D-i*1000),endAt:null,closeDelaySec:0,audience:'all',published:true}} };"%(n,len_)
with sync_playwright() as p:
    b=p.chromium.launch()
    chk('rules: per-user notificationStates (owner only, status whitelist)',"match /notificationStates/{notificationId}" in RULES and "request.resource.data.status in ['read', 'later']" in RULES and "allow read: if isOwner(userId);" in RULES)
    # ---------- الإصدار ----------
    ctx,pg,errs,st=go(b); close_notice(pg)
    v=pg.inner_text('#footerVersion')
    chk('footer shows version in MM.DD.vNN format',re.match(r'^\d\d\.\d\d\.v\d+$',v) is not None and v=='11.16.v12',v)
    pg.reload(); wait_intro(pg); pg.wait_for_timeout(500)
    chk('version does not change on reload',pg.inner_text('#footerVersion')==v)
    chk('version defined centrally (SITE_VERSION) + changelog',ev(pg,"SITE_VERSION.code")==v and ev(pg,"SITE_CHANGELOG.length")>=2)
    # ---------- الجرس: زائر ----------
    chk('guest: bell hidden',not pg.is_visible('#notifBell'))
    ctx.close()
    # ---------- الجرس: عضو نشط ----------
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg); pg.wait_for_timeout(500)
    chk('bell visible for signed-in user',pg.is_visible('#notifBell'))
    chk('bell icon is SVG (not emoji)',ev(pg,"!!document.querySelector('#notifBell svg') && !/[\\u{1F300}-\\u{1FAFF}\\u{1F514}]/u.test(document.getElementById('notifBell').textContent)"))
    chk('badge = real unread count (2: nt1 all + nt4 members; expired/hidden excluded)',pg.inner_text('#notifBadge')=='2',pg.inner_text('#notifBadge'))
    pg.click('#notifBell'); pg.wait_for_timeout(400)
    chk('panel opens with title and unread count',pg.is_visible('#notifPanel') and 'الإشعارات' in pg.inner_text('#notifTitle') and '2 غير مقروء' in pg.inner_text('#notifSub'))
    tabs=ev(pg,"Array.from(document.querySelectorAll('.notif-tab')).map(t=>t.textContent.replace(/\\s+/g,' ').trim())")
    chk('4 tabs with counts (all/unread/later/read)',len(tabs)==4 and tabs[0].endswith('2') and tabs[1].endswith('2') and tabs[2].endswith('0') and tabs[3].endswith('0'),tabs)
    it=pg.inner_text('#notifList')
    chk('item shows title, body, sender, date/time, status','فتح التسجيلات' in it and 'ندعوكم للتسجيل' in it and 'الأستاذ فلان' in it and 'جديد' in it and bool(re.search(r'\d{1,2}:\d{2}|ص|م',it)))
    chk('expired/hidden notices not listed',('منتهٍ' not in pg.inner_text('#notifList').split('فتح التسجيلات')[0]) and 'مخفي' not in it)
    # قرأت
    pg.locator('.nitem[data-id="nt1"] [data-a="read"]').click(); pg.wait_for_timeout(500)
    stt=store(pg,'users/sc1/notificationStates/nt1')
    chk('"قرأت" saves per-user state in DB',stt and stt['status']=='read')
    chk('badge decreases to 1 without reload',pg.inner_text('#notifBadge')=='1')
    chk('read item leaves unread tab and appears in read tab',(pg.click('.notif-tab[data-tab=unread]') or True) and 'فتح التسجيلات' not in pg.inner_text('#notifList') and (pg.click('.notif-tab[data-tab=read]') or True) and 'فتح التسجيلات' in pg.inner_text('#notifList'))
    # لاحقًا
    pg.click('.notif-tab[data-tab=all]'); pg.locator('.nitem[data-id="nt4"] [data-a="later"]').click(); pg.wait_for_timeout(500)
    chk('"أقرأها لاحقًا" saves state=later',store(pg,'users/sc1/notificationStates/nt4')['status']=='later')
    chk('later item stays unread and counted (badge still 1)',pg.inner_text('#notifBadge')=='1')
    pg.click('.notif-tab[data-tab=later]'); pg.wait_for_timeout(200)
    chk('later tab lists it with its own label','للقراءة لاحقًا' in pg.inner_text('#notifList') and 'للأعضاء فقط' in pg.inner_text('#notifList'))
    pg.click('.notif-tab[data-tab=unread]'); chk('later item also in unread tab','للأعضاء فقط' in pg.inner_text('#notifList'))
    # إشعار جديد لحظي
    pg.evaluate("window.__STORE['siteNotifications/ntNEW']={title:'إشعار طازج',body:'وصل للتو',issuer:'قائد الفوج',issuerName:'ق',startAt:window.__ts(Date.now()-1000),endAt:null,closeDelaySec:0,audience:'all',published:true,link:'units-page'}; window.__fire();"); pg.wait_for_timeout(500)
    chk('new notification raises badge live (1→2) without reload',pg.inner_text('#notifBadge')=='2' and 'إشعار طازج' in pg.inner_text('#notifList'))
    pg.locator('.nitem[data-id="ntNEW"] [data-go]').click(); pg.wait_for_timeout(500)
    chk('item link opens internal page and closes panel',ev(pg,"document.getElementById('units-page').classList.contains('active-page')") and not pg.is_visible('#notifPanel'))
    chk('closing panel deleted nothing',len(keys(pg,'siteNotifications/'))==5)
    seed=persist_seed(pg); ctx.close()
    # بعد إعادة التحميل: الحالة محفوظة
    ctx,pg,errs,st=go(b,'sc1',extra_seed=seed); pg.wait_for_timeout(600)
    chk('after reload: badge 2 (nt4 later + ntNEW) — nt1 stays read',pg.inner_text('#notifBadge')=='2',pg.inner_text('#notifBadge'))
    shown=[]
    for _ in range(3):
        if pg.query_selector('.se-notice'): shown.append(pg.inner_text('.se-notice'))
        close_notice(pg); pg.wait_for_timeout(250)
    chk('read notice no longer pops up on entry',not any('فتح التسجيلات' in s for s in shown),shown)
    ctx.close()
    # عزل المستخدمين
    ctx,pg,errs,st=go(b,'sc3',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(600)
    chk('another user is unaffected: still 3 unread (nt1, nt4, ntNEW)',pg.inner_text('#notifBadge')=='3',pg.inner_text('#notifBadge'))
    ctx.close()
    # حساب قيد المراجعة
    ctx,pg,errs,st=go(b,'sc2'); close_notice(pg); pg.wait_for_timeout(400)
    pg.click('#notifBell'); pg.wait_for_timeout(300); pg.locator('.nitem[data-id="nt1"] [data-a="read"]').click(); pg.wait_for_timeout(400)
    chk('pending account cannot persist read state (no write)',store(pg,'users/sc2/notificationStates/nt1') is None)
    ctx.close()
    # ---------- التمرير والتخطيط على الهاتف ----------
    ctx,pg,errs,st=go(b,'sc1',vp=(375,560),extra_seed=many(30,120)); close_notice(pg); pg.wait_for_timeout(600)
    pg.click('#notifBell'); pg.wait_for_timeout(400)
    r=ev(pg,"(()=>{const p=document.getElementById('notifPanel').getBoundingClientRect();const l=document.getElementById('notifList');const c=document.getElementById('notifClose').getBoundingClientRect();return {ph:p.height,top:p.top,bot:p.bottom,vh:innerHeight,sh:l.scrollHeight,ch:l.clientHeight,cl:[c.top,c.bottom],bodyOv:getComputedStyle(document.body).overflow}})()")
    chk('panel fits phone viewport (375x560)',r['bot']<=r['vh']+1 and r['top']>=0,r)
    chk('panel list scrolls internally; close button always visible',r['sh']>r['ch']+50 and r['cl'][0]>=0 and r['cl'][1]<=r['vh'],r)
    pg.evaluate("document.getElementById('notifList').scrollTop=99999"); pg.wait_for_timeout(200)
    last=ev(pg,"(()=>{const it=document.querySelectorAll('#notifList .nitem');const e=it[it.length-1].getBoundingClientRect();const l=document.getElementById('notifList').getBoundingClientRect();return e.bottom<=l.bottom+2})()")
    chk('last notification reachable by scrolling',last)
    chk('page body scroll locked while panel open',r['bodyOv']=='hidden')
    pg.click('#notifClose'); pg.wait_for_timeout(300)
    chk('closing panel restores page scroll',ev(pg,"getComputedStyle(document.body).overflow")!='hidden' and not pg.is_visible('#notifPanel'))
    pg.click('#notifBell'); pg.wait_for_timeout(300); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    chk('Escape closes panel',not pg.is_visible('#notifPanel'))
    pg.click('#notifBell'); pg.wait_for_timeout(300); pg.mouse.click(5,550); pg.wait_for_timeout(300)
    chk('backdrop tap closes panel',not pg.is_visible('#notifPanel'))
    # لا يتداخل مع الشريط الجانبي
    pg.click('#sidebarToggle'); pg.wait_for_timeout(450)
    chk('sidebar and panel never open together (panel hidden)',not pg.is_visible('#notifPanel') and pg.is_visible('#navMenu'))
    ctx.close()
    # ---------- إشعار الدخول الطويل ----------
    longn="var _s2=window.__SEED; window.__SEED=function(DB,ts){_s2(DB,ts); DB['siteNotifications/nt1'].body='سطر طويل جدًا. '.repeat(160); DB['siteNotifications/nt1'].closeDelaySec=2;};"
    ctx,pg,errs,st=go(b,vp=(375,560),extra_seed=longn); pg.wait_for_timeout(600)
    r=ev(pg,"(()=>{const n=document.querySelector('.se-notice');if(!n)return null;const a=n.getBoundingClientRect();const c=n.querySelector('.se-notice-close').getBoundingClientRect();const m=n.querySelector('.se-notice-main');return {nb:a.bottom,vh:innerHeight,cb:c.bottom,ct:c.top,scroll:m.scrollHeight>m.clientHeight}})()")
    chk('long login notice stays inside the phone screen with reachable close button and inner scroll',r and r['nb']<=r['vh']+1 and r['cb']<=r['vh'] and r['ct']>=0 and r['scroll'],r)
    pg.wait_for_timeout(2300)
    chk('long notice closes after delay',(pg.click('.se-notice-close') or True) and ev(pg,"!document.querySelector('.se-notice') || document.querySelector('.se-notice h3').textContent!=='فتح التسجيلات'"))
    ctx.close()
    b.close()
summary()
