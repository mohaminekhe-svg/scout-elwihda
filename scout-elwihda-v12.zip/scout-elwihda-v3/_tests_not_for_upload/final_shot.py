from playwright.sync_api import sync_playwright
ROOT='http://127.0.0.1:8765/index.html'
mock=open('mock.js').read()
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1280,'height':800}); pg=ctx.new_page()
    pg.route('**/*gstatic.com/**',lambda r: r.fulfill(body=mock if 'app-compat' in r.request.url else '',content_type='application/javascript'))
    pg.route('**/*googleapis.com/**',lambda r: r.fulfill(body='',content_type='text/css'))
    pg.route('**/*cdnjs.cloudflare.com/**',lambda r: r.fulfill(body='',content_type='text/css' if r.request.url.endswith('.css') else 'application/javascript'))
    pg.goto(ROOT); pg.wait_for_function("getComputedStyle(document.getElementById('splashScreen')).display==='none'",timeout=12000); pg.wait_for_timeout(1200)
    pg.screenshot(path='/home/claude/shots/final_home.png')
    b.close()
