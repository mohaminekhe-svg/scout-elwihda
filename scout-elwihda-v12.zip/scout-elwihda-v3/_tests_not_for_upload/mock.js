(function(){
  var now=Date.now(), DAY=86400000;
  function ts(ms){return {toMillis:function(){return ms},toDate:function(){return new Date(ms)}}}
  window.__DB={
    units:{u1:{name:'وحدة الكشاف ألف',description:'وصف',status:'active',order:1,scoutCount:12,imageName:'',pub:{leaderName:'قائد <img src=x onerror=window.__xss=1>'}},
           u2:{name:'عشيرة الجوالة',status:'active',order:2,pub:{}}},
    activities:{a1:{title:'تجمع قادم',description:'وصف النشاط',kind:'gathering',unitId:'u1',startAt:ts(now+3*DAY),location:'الحميز',status:'published'},
                a2:{title:'نشاط سابق',kind:'camp',unitId:'u1',startAt:ts(now-5*DAY),status:'published'},
                a3:{title:'بعيد <script>window.__xss=2</script>',kind:'trip',startAt:ts(now+30*DAY),status:'published'}},
    announcements:{n1:{title:'خبر رحلة',content:'x',category:'trips',published:true,createdAt:ts(now)},n2:{title:'خبر عام',content:'y',category:'',published:true,createdAt:ts(now-1000)}},
    gallery:{}, settings:{}
  };
  function snap(col,filters){var docs=[];var c=window.__DB[col]||{};Object.keys(c).forEach(function(id){var d=c[id];var ok=(filters||[]).every(function(f){return d[f[0]]===f[1]});if(ok)docs.push({id:id,data:function(){return d},exists:true})});
    return {empty:!docs.length,size:docs.length,docs:docs,forEach:function(f){docs.forEach(f)}}}
  function query(col,filters){return {where:function(a,b,c){return query(col,(filters||[]).concat([[a,c]]))},orderBy:function(){return query(col,filters)},limit:function(){return query(col,filters)},
    get:function(){return Promise.resolve(snap(col,filters))},onSnapshot:function(cb){setTimeout(function(){cb(snap(col,filters))},0);return function(){}}}}
  var fsfn=function(){return {collection:function(c){var q=query(c);q.doc=function(id){id=id||('gen'+Math.random().toString(36).slice(2,6));return {path:c+'/'+id,id:id,get:function(){return Promise.resolve({exists:false,data:function(){return {}}})},set:function(){return Promise.resolve()},update:function(){return Promise.resolve()},delete:function(){return Promise.resolve()},onSnapshot:function(cb){setTimeout(function(){cb({exists:false,data:function(){return {}}})},0);return function(){}}}};q.add=function(){return Promise.resolve({id:'n'})};return q},
    batch:function(){var w=window.__writes=window.__writes||[];return {set:function(r,d){w.push(['set',r.path,d])},update:function(r,d){w.push(['update',r.path,d])},delete:function(r){w.push(['delete',r.path])},commit:function(){return Promise.resolve()}}},enablePersistence:function(){return Promise.resolve()},settings:function(){}}};
  fsfn.FieldValue={serverTimestamp:function(){return 'TS'}};fsfn.Timestamp={fromMillis:function(m){return ts(m)},now:function(){return ts(Date.now())}};
  var authObj={currentUser:null,onAuthStateChanged:function(cb){setTimeout(function(){cb(null)},0)},signOut:function(){return Promise.resolve()},setPersistence:function(){return Promise.resolve()},sendPasswordResetEmail:function(e){window.__reset=(window.__reset||0)+1;return Promise.resolve()},useDeviceLanguage:function(){}};
  var af=function(){return authObj};af.Auth={Persistence:{LOCAL:'l',SESSION:'s',NONE:'n'}};
  window.firebase={initializeApp:function(){return {name:'x',auth:af,firestore:fsfn}},apps:[],app:function(){return {}},auth:af,firestore:fsfn};
})();
