from playwright.sync_api import sync_playwright
mock=open('mock.js').read()
res=[]
def chk(n,c): res.append(bool(c)); print(('PASS ' if c else 'FAIL ')+n)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':375,'height':640})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.route('**/*gstatic.com/**',lambda r: r.fulfill(body=mock if 'app-compat' in r.request.url else '',content_type='application/javascript'))
    pg.route('**/*cdnjs.cloudflare.com/**',lambda r: r.fulfill(body='',content_type='text/css'))
    pg.route('**/*googleapis.com/**',lambda r: r.fulfill(body='',content_type='text/css'))
    pg.goto('http://127.0.0.1:8765/index.html#news-abc'); pg.wait_for_timeout(300)
    pg.wait_for_function("getComputedStyle(document.getElementById('splashScreen')).display==='none'",timeout=12000); chk('deep link: intro shown then ends',True)
    # footer / privacy placement
    chk('footer has no privacy link',pg.evaluate("document.querySelector('.site-footer').innerText.indexOf('سياسة الخصوصية')===-1"))
    chk('privacy link inside registration modal',pg.evaluate("document.querySelectorAll('#scoutParentRegisterModal .privacy-link').length>0"))
    # non-admin blocked
    pg.evaluate("window.__writes=[]; V3.openUnitForm()"); pg.evaluate("document.getElementById('unitName').value='x'"); pg.evaluate("document.getElementById('unitForm').requestSubmit()"); pg.wait_for_timeout(200)
    chk('non-admin cannot save unit',pg.evaluate("window.__writes.length")==0)
    pg.evaluate("closeModal('unitFormModal'); currentUserRole='admin'")
    # modal scroll + overflow at 375
    pg.evaluate("V3.openUnitForm()"); pg.wait_for_timeout(200)
    m=pg.evaluate("(()=>{const e=document.querySelector('#unitFormModal .v3-modal');return [e.scrollHeight>e.clientHeight,getComputedStyle(e).overflowY,document.documentElement.scrollWidth<=innerWidth]})()")
    chk('unit form scrolls on 375px, no h-overflow',m[0] and m[1]=='auto' and m[2])
    pg.evaluate("document.getElementById('unitFormSubmit').scrollIntoView()")
    chk('submit button reachable',pg.is_visible('#unitFormSubmit'))
    # privacy: contacts not published unless checked (النموذج الجديد: 3 قادة)
    pg.evaluate("V3.openUnitForm()"); pg.wait_for_timeout(300)
    pg.fill('#unitName','وحدة تجريبية'); pg.fill('#ul1Name','قائد'); pg.fill('#ul1Phone','0555123456'); pg.fill('#ul1Email','q@x.dz'); pg.check('#unitPublishNames')
    pg.evaluate("document.getElementById('unitForm').requestSubmit()"); pg.wait_for_timeout(500)
    w=pg.evaluate("window.__writes")
    pubw=[x for x in w if x[1] and x[1].startswith('units/')]
    privw=[x for x in w if x[1] and x[1].startswith('unitPrivate/')]
    chk('public doc has name but NOT phone/email',pubw and pubw[0][2]['pub']['leaders'][0].get('name')=='قائد' and 'phone' not in pubw[0][2]['pub']['leaders'][0] and 'email' not in pubw[0][2]['pub']['leaders'][0])
    chk('private doc stores phone+email',privw and privw[0][2]['leaders'][0]['phone']=='0555123456' and privw[0][2]['leaders'][0]['email']=='q@x.dz')
    pg.evaluate("V3.openUnitForm()"); pg.wait_for_timeout(300); pg.fill('#unitName','وحدة'); pg.fill('#ul1Email','not-an-email'); pg.evaluate("window.__writes=[]; document.getElementById('unitForm').requestSubmit()"); pg.wait_for_timeout(300)
    chk('invalid leader email rejected',('بريد القائد' in pg.inner_text('#unitFormError')) and pg.evaluate("window.__writes.length")==0)
    # activity form validation
    pg.evaluate("window.__writes=[]; V3.openActivityForm()"); pg.fill('#actTitle','نشاط'); pg.evaluate("document.getElementById('activityForm').requestSubmit()"); pg.wait_for_timeout(200)
    chk('activity requires valid date',('تاريخ' in pg.inner_text('#activityFormError')))
    # seed refuses when list not empty
    pg.evaluate("V3.loadAdminUnits()"); pg.wait_for_timeout(300)
    pg.evaluate("window.__writes=[]; window.confirm=()=>true; V3.seedDefaultUnits()"); pg.wait_for_timeout(200)
    chk('seed refuses when units exist',pg.evaluate("window.__writes.length")==0)
    chk('admin list rendered',pg.inner_text('#unitsAdminList').count('تعديل')>=2)
    chk('no page errors '+str(errs[:2]),not errs)
    b.close()
print('TOTAL',sum(res),'/',len(res))
