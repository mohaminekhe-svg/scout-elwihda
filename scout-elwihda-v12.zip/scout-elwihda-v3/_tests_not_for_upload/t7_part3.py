from h5 import *
H='#postEngagementHost'
def open_post(pg,pid='n1'):
    ev(pg,"showPage('latest-news-page')"); pg.wait_for_timeout(400); ev(pg,f"openNewsDetail('{pid}')"); pg.wait_for_timeout(1000)
with sync_playwright() as p:
    b=p.chromium.launch()
    # ================= تعليقات: ردود + إعجاب + إعجاب رسمي =================
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg); pg.wait_for_timeout(600); ERR=errs
    open_post(pg)
    pg.fill(H+' .cm-form textarea','تعليق أصلي'); pg.click(H+' .cm-form button[type=submit]'); pg.wait_for_timeout(800)
    cid=[k for k in keys(pg,'announcements/n1/comments/')][0].split('/')[-1]
    chk('top-level comment has reply and like controls but own comment shows no official-like button',bool(pg.query_selector(H+' [data-reply]')) and bool(pg.query_selector(H+' [data-like]')) and not pg.query_selector(H+' [data-official]'))
    seed=persist_seed(pg); ctx.close()
    ctx,pg,errs,st=go(b,'sc3',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(600); open_post(pg)
    pg.click(H+' [data-reply="%s"]'%cid); pg.wait_for_timeout(200)
    pg.fill(H+' .cm-replybox textarea','رد على التعليق'); pg.click(H+' .cm-replybox button[type=submit]'); pg.wait_for_timeout(900)
    rep=[store(pg,k) for k in keys(pg,'announcements/n1/comments/') if store(pg,k).get('parentId')]
    chk('reply saved with parentId, own uid and name',len(rep)==1 and rep[0]['parentId']==cid and rep[0]['uid']=='sc3' and rep[0]['hidden'] is False)
    chk('reply appears nested under the original comment with its author',ev(pg,"(()=>{const c=document.querySelector('#postEngagementHost .cm-item[data-cid=\"%s\"]');return !!c && c.querySelector('.cm-replies .cm-reply') && c.querySelector('.cm-replies').innerText.includes('رد على التعليق') && c.querySelector('.cm-replies').innerText.includes('كشاف ثالث')})()"%cid))
    chk('no reply button on replies (one level)',ev(pg,"document.querySelectorAll('#postEngagementHost .cm-reply [data-reply]').length")==0)
    # إعجاب بتعليق
    pg.locator(H+' [data-like="%s"]'%cid).click(); pg.wait_for_timeout(700)
    chk('comment like saved (doc id = uid) and count real=1',store(pg,'announcements/n1/comments/%s/likes/sc3'%cid) is not None and ev(pg,"document.querySelector('#postEngagementHost [data-like=\"%s\"] span').textContent"%cid)=='1')
    pg.locator(H+' [data-like="%s"]'%cid).click(); pg.wait_for_timeout(700)
    chk('like toggles off (no duplicates)',store(pg,'announcements/n1/comments/%s/likes/sc3'%cid) is None)
    chk('regular user has no official-like control',not pg.query_selector(H+' [data-official]'))
    r=ev(pg,"db.collection('announcements').doc('n1').collection('comments').doc('%s').collection('officialLike').doc('leader').set({uid:'sc3',name:'x',roleLabel:'قائد الفوج',photoURL:'',createdAt:firebase.firestore.FieldValue.serverTimestamp()}).then(()=>'allowed').catch(e=>e.code)"%cid)
    chk('regular user cannot forge the official like (server-side rule)',r=='permission-denied',r)
    seed=persist_seed(pg); ctx.close()
    ctx,pg,errs,st=go(b,'admin1',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(1200); open_post(pg)
    chk('group leader sees official-like control',bool(pg.query_selector(H+' [data-official="%s"]'%cid)))
    pg.click(H+' [data-official="%s"]'%cid); pg.wait_for_timeout(1000)
    ol=store(pg,'announcements/n1/comments/%s/officialLike/leader'%cid)
    chk('official like stored with leader name, role label, time',ol and ol['uid']=='admin1' and ol['name']=='مدير الموقع' and ol['roleLabel']=='قائد الفوج' and ol['createdAt'])
    chk('distinct official badge shown (name + role)','إعجاب رسمي' in pg.inner_text(H+' .cm-official') and 'مدير الموقع' in pg.inner_text(H+' .cm-official') and 'قائد الفوج' in pg.inner_text(H+' .cm-official'))
    ib=keys(pg,'users/sc1/inbox/')
    chk('comment owner notified (inbox)',len(ib)==1 and 'إعجاب رسمي' in store(pg,ib[0])['title'])
    chk('official like logged',any(store(pg,k)['action']=='official_like' for k in keys(pg,'adminLogs/')))
    seed=persist_seed(pg); ctx.close()
    ctx,pg,errs,st=go(b,'sc3',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(800); open_post(pg)
    chk('other users see the official badge on the comment',bool(pg.query_selector(H+' .cm-official')))
    ctx.close()
    ctx,pg,errs,st=go(b,'sc1',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(1000)
    pg.click('#notifBell'); pg.wait_for_timeout(300)
    chk('owner sees the official-like notification in the bell','إعجاب رسمي من قائد الفوج' in pg.inner_text('#notifList'))
    ctx.close()
    ctx,pg,errs,st=go(b,'admin1',extra_seed=seed); close_notice(pg); pg.wait_for_timeout(1200); open_post(pg)
    pg.click(H+' [data-official="%s"]'%cid); pg.wait_for_timeout(900)
    chk('official like can be removed by the leader',store(pg,'announcements/n1/comments/%s/officialLike/leader'%cid) is None)
    pg.on('dialog',lambda d: d.accept())
    pg.locator(H+' [data-del="%s"]'%cid).click(); pg.wait_for_timeout(900)
    left=[k for k in keys(pg,'announcements/n1/comments/') if k.count('/')==3]
    chk('admin deletes comment together with its replies',len(left)==0,left)
    chk('comment deletion by admin logged',any(store(pg,k)['action']=='comment_delete' for k in keys(pg,'adminLogs/')))
    ctx.close()
    chk('no JS errors in comment flows',not ERR,ERR)

    # ================= قائد الوحدة: وحدته فقط =================
    ctx,pg,errs,st=go(b,'lead1'); close_notice(pg); pg.wait_for_timeout(1000); ERR2=errs
    nav(pg,'units-page'); pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(900)
    chk('unit leader sees «إدارة وحدتي» on own unit page',bool(pg.query_selector('#unitDetailBody .ud-manage button')))
    pg.click('#unitDetailBody .ud-manage button'); pg.wait_for_timeout(600)
    chk('leader form: name/status locked, content editable',ev(pg,"document.getElementById('unitName').disabled && document.getElementById('unitStatus').disabled && !document.getElementById('unitDesc').disabled"))
    pg.fill('#unitDesc','وصف جديد من قائد الوحدة'); pg.click('#unitFormSubmit'); pg.wait_for_timeout(1200)
    u=store(pg,'units/u1')
    chk('leader saved own unit content; name/status unchanged',u['description']=='وصف جديد من قائد الوحدة' and u['name']=='وحدة الكشاف ألف' and u['status']=='active',u)
    pg.click('#unitBackBtn'); pg.wait_for_timeout(300); pg.click('#unitsGrid [data-unit="u2"]'); pg.wait_for_timeout(800)
    chk('no manage button on other units',not pg.query_selector('#unitDetailBody .ud-manage'))
    r=ev(pg,"db.collection('units').doc('u2').update({description:'x',updatedAt:firebase.firestore.FieldValue.serverTimestamp()}).then(()=>'allowed').catch(e=>e.code)")
    chk("leader cannot edit another unit (server rule)",r=='permission-denied',r)
    r=ev(pg,"db.collection('units').doc('u1').update({name:'مخترقة'}).then(()=>'allowed').catch(e=>e.code)")
    chk('leader cannot rename/archive own unit (server rule)',r=='permission-denied',r)
    chk('no JS errors for unit leader',not ERR2,ERR2)
    ctx.close()
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg); nav(pg,'units-page'); pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(800)
    chk('scout has no manage button',not pg.query_selector('#unitDetailBody .ud-manage'))
    ctx.close()

    # ================= تخطيط: 360/375/390/1366 =================
    PAGES=['home-page','latest-news-page','next-gathering-page','past-programs-page','bulletin-page','units-page','gallery-page','skills-page','about-page','settings-page','search-page']
    for vp,label in [((360,740),'360'),((375,740),'375'),((390,844),'390'),((1366,768),'1366')]:
        ctx,pg,errs,st=go(b,'sc1',vp=vp); close_notice(pg)
        bad=[]
        for pid in PAGES:
            ev(pg,f"showPage('{pid}')"); pg.wait_for_timeout(250)
            if ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth"): bad.append(pid)
        for sec in ['profile','security','contact','language','privacy','support','card']:
            ev(pg,"showPage('settings-page')"); pg.wait_for_timeout(120); ev(pg,f"V6.openSection('{sec}')"); pg.wait_for_timeout(200)
            if ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth"): bad.append('settings/'+sec)
        chk(f'{label}px: no horizontal scroll (pages + settings sub-pages)',not bad,bad)
        chk(f'{label}px: no JS errors',not errs,errs)
        ctx.close()
    # لوحة الإدارة على 360
    ctx,pg,errs,st=go(b,'admin1',vp=(360,640)); close_notice(pg); pg.wait_for_timeout(800)
    ev(pg,"setAdminViewActive(true)"); bad=[]
    for tab in ['accounts-tab','approvals-tab','support-admin-tab','logs-tab','backups-tab','notifications-tab','units-tab']:
        ev(pg,f"switchAdminTab('{tab}')"); pg.wait_for_timeout(500)
        if ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth"): bad.append(tab)
        m=ev(pg,"(()=>{const v=document.querySelector('.admin-main-viewport');return v.scrollHeight>=v.clientHeight})()")
    chk('360px: new admin tabs have no horizontal overflow',not bad,bad)
    chk('360px: no JS errors in admin',not errs,errs)
    ctx.close()
    b.close()
summary()
