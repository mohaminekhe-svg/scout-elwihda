import re
from h5 import *
JS_REACH = """(sel)=>{ // آخر عنصر تفاعلي داخل النافذة يمكن الوصول إليه بالتمرير ضمن الشاشة
  const m=document.querySelector(sel); if(!m) return {err:'missing '+sel};
  const btns=[...m.querySelectorAll('button,a,input,select,textarea')].filter(b=>b.offsetParent!==null);
  const subs=btns.filter(b=>b.type==='submit'); const last=subs.length?subs[subs.length-1]:btns[btns.length-1];
  const chain=[]; let e=last; while(e&&e!==document.body){ chain.push(e); e=e.parentElement; }
  chain.forEach(x=>{ if(x.scrollHeight>x.clientHeight+2) x.scrollTop=x.scrollHeight; });
  const r=last.getBoundingClientRect();
  const cls=m.querySelector('.v3-modal-close,.close-btn,.modal-close,[aria-label="إغلاق"]'); const cr=cls?cls.getBoundingClientRect():null;
  return {lastBottom:r.bottom,lastTop:r.top,vh:innerHeight,closeTop:cr?cr.top:null,closeBottom:cr?cr.bottom:null,n:btns.length};
}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---------- الشريط الجانبي على هاتف قصير ----------
    ctx,pg,errs,st=go(b,'admin1',vp=(375,480)); close_notice(pg)
    ev(pg,"showPage('units-page')"); pg.wait_for_timeout(300)
    pg.click('#sidebarToggle'); pg.wait_for_timeout(500)
    m=ev(pg,"(()=>{const n=document.getElementById('navMenu');return {sh:n.scrollHeight,ch:n.clientHeight,ov:getComputedStyle(n).overflowY,h:n.getBoundingClientRect().height,vh:innerHeight}})()")
    chk('drawer is scrollable independently when content is long',m['sh']>m['ch'] and m['ov'] in ('auto','scroll') and m['h']<=m['vh']+1,m)
    pg.evaluate("document.getElementById('navMenu').scrollTop=99999"); pg.wait_for_timeout(200)
    r=ev(pg,"(()=>{const lis=[...document.querySelectorAll('#navMenu li')].filter(l=>l.offsetParent);const last=lis[lis.length-1].getBoundingClientRect();const c=document.querySelector('#navMenu .menu-close-btn').getBoundingClientRect();return {lastBottom:last.bottom,vh:innerHeight,closeTop:c.top,closeBottom:c.bottom}})()")
    chk('bottom-most item reachable after scrolling the drawer',r['lastBottom']<=r['vh']+1,r)
    chk('close button stays visible while drawer is scrolled',r['closeTop']>=0 and r['closeBottom']<=r['vh'],r)
    pg.click('#navMenu .menu-close-btn'); pg.wait_for_timeout(400)
    chk('after closing drawer page scroll is back to normal (no lock class)',ev(pg,"!document.body.classList.contains('menu-scroll-locked') && getComputedStyle(document.body).overflow!=='hidden'"))
    ev(pg,"document.getElementById('unitsGrid').style.minHeight='2500px'"); pg.evaluate("window.scrollTo(0,800)"); pg.wait_for_timeout(300)
    chk('page can scroll after drawer closed',ev(pg,"scrollY")>=700)
    ctx.close()
    # ---------- النوافذ الطويلة ----------
    longc="var _s3=window.__SEED; window.__SEED=function(DB,ts){_s3(DB,ts); DB['announcements/n1'].content='فقرة طويلة جدًا. '.repeat(500);};"
    ctx,pg,errs,st=go(b,'admin1',vp=(375,520),extra_seed=longc); close_notice(pg)
    ev(pg,"showPage('latest-news-page')"); pg.wait_for_timeout(500); ev(pg,"openNewsDetail('n1')"); pg.wait_for_timeout(1000)
    r=ev(pg,"("+JS_REACH+")('#newsDetailModal')")
    chk('long news modal: bottom content (comments form) reachable by scrolling',r.get('lastBottom',9999)<=r.get('vh',0)+2 and r.get('lastTop',-1)>=0,r)
    box=ev(pg,"(()=>{const b=document.querySelector('#newsDetailModal .news-detail-box, #newsDetailModal > div');const r=b.getBoundingClientRect();return {h:r.height,vh:innerHeight}})()")
    chk('modal box never exceeds phone height',box['h']<=box['vh']-12,box)
    ev(pg,"document.querySelector('#newsDetailModal').scrollTop=0; document.querySelectorAll('#newsDetailModal *').forEach(x=>{x.scrollTop=0})"); pg.wait_for_timeout(200)
    cb=ev(pg,"(()=>{const c=document.querySelector('#newsDetailModal [aria-label=\"إغلاق\"], #newsDetailModal .news-detail-close, #newsDetailModal .close-btn');if(!c)return null;const r=c.getBoundingClientRect();return [r.top,r.bottom,innerHeight]})()")
    chk('news modal close button reachable',cb is not None and cb[0]>=0 and cb[1]<=cb[2],cb)
    ev(pg,"closeModal('newsDetailModal')")
    for mid,opener in [('unitFormModal',"V3.openUnitForm()"),('activityFormModal',"V3.openActivityForm()"),('noticeFormModal',"SENotice.openForm()"),('adminAnnouncementModal',"openAnnouncementModal('add')")]:
        if ev(pg,f"!document.getElementById('{mid}')"): continue
        ev(pg,opener); pg.wait_for_timeout(500)
        r=ev(pg,"("+JS_REACH+f")('#{mid}')")
        chk(f'{mid}: submit/last control reachable on 375x520',r.get('lastBottom',9999)<=r.get('vh',0)+2 and r.get('lastTop',-1)>=0,r)
        ev(pg,f"closeModal('{mid}')")
    ctx.close()
    # ---------- لوحة الإدارة على الهاتف ----------
    ctx,pg,errs,st=go(b,'admin1',vp=(375,520)); close_notice(pg); pg.wait_for_timeout(300)
    ev(pg,"setAdminViewActive(true)"); pg.wait_for_timeout(600)
    pg.evaluate("document.querySelector('.admin-mobile-toggle-btn, #adminMobileToggle, .admin-menu-toggle') && document.querySelector('.admin-mobile-toggle-btn, #adminMobileToggle, .admin-menu-toggle').click()"); pg.wait_for_timeout(400)
    s=ev(pg,"(()=>{const a=document.querySelector('.admin-sidebar');const cs=getComputedStyle(a);return {ov:cs.overflowY,sh:a.scrollHeight,ch:a.clientHeight,btn:[...a.querySelectorAll('.admin-nav-btn')].length,minH:Math.min(...[...a.querySelectorAll('.admin-nav-btn')].map(b=>b.getBoundingClientRect().height))}})()")
    chk('admin sidebar scrolls (not hidden) and buttons are not squashed',s['ov'] in ('auto','scroll') and s['minH']>=40,s)
    pg.evaluate("document.querySelector('.admin-sidebar').scrollTop=99999"); pg.wait_for_timeout(200)
    r=ev(pg,"(()=>{const a=document.querySelector('.admin-sidebar');const bs=[...a.querySelectorAll('button')].filter(b=>b.offsetParent);const l=bs[bs.length-1].getBoundingClientRect();const ar=a.getBoundingClientRect();return {lastBottom:l.bottom,sideBottom:ar.bottom,vh:innerHeight}})()")
    chk('last admin sidebar button (logout/back) reachable by scroll',r['lastBottom']<=r['vh']+1,r)
    ev(pg,"switchAdminTab('units-tab')"); pg.wait_for_timeout(500)
    ev(pg,"document.getElementById('unitsAdminList').style.minHeight='3000px'")
    m=ev(pg,"(()=>{const v=document.querySelector('.admin-main-viewport');const cs=getComputedStyle(v);v.scrollTop=99999;return {ov:cs.overflowY,sh:v.scrollHeight,ch:v.clientHeight,top:v.scrollTop,vh:innerHeight,h:v.getBoundingClientRect().height}})()")
    chk('admin main area scrolls up/down on phone (not capped by fixed height)',m['ov'] in ('auto','scroll') and m['top']>100 and m['h']<=m['vh']+1,m)
    ev(pg,"switchAdminTab('notifications-tab')"); pg.wait_for_timeout(500)
    ov=ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth")
    chk('admin: no horizontal page scroll on 375px',not ov)
    ev(pg,"setAdminViewActive(false)"); pg.wait_for_timeout(400)
    chk('leaving admin view restores page scrolling',ev(pg,"!document.body.classList.contains('admin-view-open')"))
    ctx.close()
    # ---------- الرئيسية على الهاتف ----------
    ctx,pg,errs,st=go(b,vp=(375,740)); close_notice(pg)
    ev(pg,"showPage('home-page')"); pg.wait_for_timeout(400)
    vis=lambda sel: ev(pg,f"(()=>{{const e=document.querySelector('{sel}');return !!e && getComputedStyle(e).display!=='none' && e.offsetParent!==null}})()")
    chk('mobile home: duplicate hero buttons removed',not vis('.royal-hero-actions'))
    chk('mobile home: duplicate top "view all" buttons removed; one bottom button kept',not vis('.latest-news-header .news-view-all-btn') and vis('#latest-news .section-more button'))
    chk('mobile home: nav links still available (sidebar)',(pg.click('#sidebarToggle') or True) and pg.is_visible('#navMenu .nav-group-btn[data-page="latest-news-page"]') and pg.is_visible('#navMenu .nav-group-btn[data-page="next-gathering-page"]'))
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    hh=ev(pg,"document.querySelector('.royal-hero').getBoundingClientRect().height")
    chk('mobile home: hero not oversized (<=300px)',hh<=300,hh)
    chk('mobile home: news then next program are in order and visible',ev(pg,"(()=>{const n=document.getElementById('latest-news').getBoundingClientRect().top;const x=document.getElementById('next-activity').getBoundingClientRect().top;return n<x})()"))
    ctx.close()
    # ---------- الاسم «فوج الوحدة» + عدم التمرير الأفقي + تداخل الأزرار ----------
    PAGES=['home-page','latest-news-page','next-gathering-page','past-programs-page','bulletin-page','units-page','gallery-page','skills-page','about-page','settings-page']
    for vp,label in [((375,740),'375'),((390,844),'390'),((1366,768),'1366')]:
        ctx,pg,errs,st=go(b,'sc1',vp=vp); close_notice(pg)
        bad_h=[];bad_name=[];bad_ov=[]
        for pid in PAGES:
            ev(pg,f"showPage('{pid}')"); pg.wait_for_timeout(300)
            if ev(pg,"document.documentElement.scrollWidth>document.documentElement.clientWidth"): bad_h.append(pid)
            if 'فوج الوحدة الكشفي' in ev(pg,"document.body.innerText"): bad_name.append(pid)
            ov=ev(pg,"""(()=>{const out=[];document.querySelectorAll('.site-page.active-page button, .site-page.active-page .v3-btn, .site-page.active-page a.nb').forEach(a=>{});
              const groups=[...document.querySelectorAll('.site-page.active-page .btn-row, .site-page.active-page .v3-form-actions, .site-page.active-page .v5-row, .site-page.active-page .latest-news-header, .site-page.active-page .set-menu, .site-page.active-page .section-more')];
              groups.forEach(g=>{const bs=[...g.querySelectorAll('button,a')].filter(b=>b.offsetParent);for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++){const a=bs[i].getBoundingClientRect(),c=bs[j].getBoundingClientRect();if(a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1)out.push(g.className)}});return out})()""")
            if ov: bad_ov.append((pid,ov[:2]))
        chk(f'{label}px: no horizontal scroll on {len(PAGES)} pages',not bad_h,bad_h)
        chk(f'{label}px: «فوج الوحدة الكشفي» never shown',not bad_name,bad_name)
        chk(f'{label}px: no overlapping buttons in action rows',not bad_ov,bad_ov)
        chk(f'{label}px: no JS errors',not errs,errs)
        # توسيط المحتوى
        ev(pg,"showPage('units-page')"); pg.wait_for_timeout(300)
        cen=ev(pg,"(()=>{const c=document.querySelector('#units-page .container');const r=c.getBoundingClientRect();return Math.abs((r.left+r.right)/2-innerWidth/2)})()")
        chk(f'{label}px: content centered',cen<=12,cen)
        ctx.close()
    b.close()
summary()
