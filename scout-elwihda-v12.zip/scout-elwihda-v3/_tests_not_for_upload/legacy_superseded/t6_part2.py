import re
from h5 import *
def settings_open(pg,sec=None):
    nav(pg,'settings-page'); pg.wait_for_timeout(300)
    if sec: pg.click(f'#settingsMenu [data-sec="{sec}"]'); pg.wait_for_timeout(300)
with sync_playwright() as p:
    b=p.chromium.launch()
    # ================= الإعدادات =================
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg)
    ERR=errs
    openmenu(pg)
    items=ev(pg,"Array.from(document.querySelectorAll('#navMenu .nav-btn')).filter(b=>b.offsetParent).map(b=>b.textContent.replace(/\\s+/g,' ').trim())")
    chk('sidebar: profile/card entries moved into Settings; Settings + Logout present',not any(t in ' | '.join(items) for t in ['الملف الشخصي','بطاقتي']) and any('الإعدادات' in t for t in items) and any('تسجيل الخروج' in t for t in items),items)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    settings_open(pg)
    tiles=ev(pg,"Array.from(document.querySelectorAll('#settingsMenu .set-tile')).map(t=>t.getAttribute('data-sec'))")
    chk('settings is a full page with 8 section tiles (not one long page)',tiles==['profile','card','account','language','privacy','notifications','password','about'],tiles)
    chk('only the menu is visible at first (no stacked panels)',ev(pg,"Array.from(document.querySelectorAll('.set-panel')).every(p=>p.hidden)"))
    for sec in tiles:
        pg.click(f'#settingsMenu [data-sec="{sec}"]'); pg.wait_for_timeout(250)
        ok=ev(pg,f"(()=>{{const p=document.querySelector('.set-panel[data-sec={sec}]');return !p.hidden && document.getElementById('settingsMenu').hidden && location.hash==='#settings-{sec}'}})()")
        chk(f'settings section opens: {sec}',ok)
        pg.click(f'.set-panel[data-sec="{sec}"] .set-back'); pg.wait_for_timeout(250)
        if not ev(pg,"!document.getElementById('settingsMenu').hidden"): chk(f'back from {sec}',False)
    chk('back button returns to sections menu',ev(pg,"!document.getElementById('settingsMenu').hidden"))
    # الملف الشخصي
    pg.click('#settingsMenu [data-sec="profile"]'); pg.wait_for_timeout(300)
    chk('profile section shows editable fields + read-only email',pg.input_value('#pfEmail')=='sc1@x.dz' and ev(pg,"document.getElementById('pfEmail').readOnly") and pg.input_value('#pfPhone')=='0550123456')
    pg.fill('#pfNickname','الصقر'); pg.fill('#pfPhone','0661234567'); pg.fill('#pfBirthDate','2011-03-02'); pg.fill('#pfBirthPlace','البليدة'); pg.click('#profileSaveBtn'); pg.wait_for_timeout(800)
    u=store(pg,'users/sc1')
    chk('profile data saved (phone/nickname/birth) and sensitive fields untouched',u['nickname']=='الصقر' and u['scoutPhone']=='0661234567' and u['birthPlace']=='البليدة' and u['email']=='sc1@x.dz' and u['role']=='scout' and u['accountStatus']=='active' and u['unitId']=='u1')
    # صورة
    pg.set_input_files('#settingsPhotoUploader input[type=file]','t_land.jpg'); pg.wait_for_timeout(300)
    chk('photo preview before upload; nothing uploaded yet',bool(pg.query_selector('#settingsPhotoUploader .se-up-prev img')) and len(st['uploads'])==0)
    pg.set_input_files('#settingsPhotoUploader input[type=file]','bad.txt'); pg.wait_for_timeout(200)
    chk('invalid file type rejected with clear message','غير مدعوم' in pg.inner_text('#settingsPhotoUploader .se-up-msg'))
    pg.set_input_files('#settingsPhotoUploader input[type=file]','t_land.jpg'); pg.wait_for_timeout(200)
    st['fail']=True; pg.click('#settingsPhotoSave'); pg.wait_for_timeout(1500)
    chk('upload failure: clear error, no fake link saved, old photo kept',('تعذّر' in pg.inner_text('#settingsPhotoMsg')) and not store(pg,'users/sc1').get('photoURL'),pg.inner_text('#settingsPhotoMsg'))
    st['fail']=False; n0=len(st['uploads']); pg.click('#settingsPhotoSave'); pg.wait_for_timeout(1800)
    u=store(pg,'users/sc1')
    chk('retry uploads and saves correct Drive URL+id',u.get('photoFileId','').startswith('UP') and 'drive.google.com/thumbnail?id='+u['photoFileId'] in u.get('photoURL',''))
    chk('profile upload uses kind=profiles and p_<uid>- file name (own-delete rule)',st['uploads'][-1]['kind']=='profiles' and st['uploads'][-1]['fileName'].startswith('p_sc1-'),st['uploads'][-1].get('fileName'))
    chk('avatar circular in profile section',ev(pg,"getComputedStyle(document.getElementById('profileAvatar')).borderRadius")=='50%' and bool(pg.query_selector('#profileAvatar img')))
    first_id=u['photoFileId']
    # استبدال الصورة: لا حذف قبل النجاح؛ ثم يُطلب حذف القديمة
    pg.set_input_files('#settingsPhotoUploader input[type=file]','t_port.png'); pg.wait_for_timeout(200); pg.click('#settingsPhotoSave'); pg.wait_for_timeout(1800)
    deletes=[x for x in st['uploads'] if x.get('action')=='delete']
    chk('replace photo: new saved first, then old deleted (delete request for old id)',store(pg,'users/sc1')['photoFileId']!=first_id and any(d.get('fileId')==first_id for d in deletes))
    # البطاقة
    pg.click('.set-panel[data-sec="profile"] .set-back'); pg.click('#settingsMenu [data-sec="card"]'); pg.wait_for_timeout(400)
    card=ev(pg,"(()=>{const c=document.querySelector('.id-card');const r=c.getBoundingClientRect();const a=c.querySelector('.avatar-circle');return {w:r.width,h:r.height,ratio:r.width/r.height,r:getComputedStyle(a).borderRadius,img:!!a.querySelector('img'),txt:c.innerText}})()")
    chk('card is horizontal ID-style (ratio ~1.586) and compact',1.5<=card['ratio']<=1.7 and card['w']<=541,card)
    t=card['txt']
    chk('card has circular photo, name, nickname, group «فوج الوحدة», unit, phone, email',card['r']=='50%' and card['img'] and 'كشاف أول' in t and 'الصقر' in t and 'فوج الوحدة' in t and 'وحدة الكشاف ألف' in t and '0661234567' in t and 'sc1@x.dz' in t,t)
    chk('card does not use «فوج الوحدة الكشفي»','فوج الوحدة الكشفي' not in t)
    chk('card shows only my data (not other users)','كشاف ثالث' not in t and 'sc3@x.dz' not in t)
    chk('print button + print CSS present',pg.is_visible('#cardPrintBtn'))
    # الحساب + المحفوظات + الخروج
    pg.click('.set-panel[data-sec="card"] .set-back'); pg.click('#settingsMenu [data-sec="account"]'); pg.wait_for_timeout(300)
    chk('account section: info + saved posts + logout at bottom',('sc1@x.dz' in pg.inner_text('#settingsInfo')) and pg.is_visible('#savedPostsList') and pg.is_visible('#settingsLogoutBtn'))
    # الخصوصية
    pg.click('.set-panel[data-sec="account"] .set-back'); pg.click('#settingsMenu [data-sec="privacy"]'); pg.wait_for_timeout(300)
    pg.check('input[name=prvName][value=first]'); pg.wait_for_timeout(600)
    chk('privacy choice saved to profile prefs',store(pg,'users/sc1').get('prefs',{}).get('commentName')=='first')
    ev(pg,"showPage('latest-news-page')"); pg.wait_for_timeout(500); ev(pg,"openNewsDetail('n2')"); pg.wait_for_timeout(900)
    pg.fill('#postEngagementHost .cm-form textarea','تعليق بالاسم الأول'); pg.click('#postEngagementHost .cm-form button[type=submit]'); pg.wait_for_timeout(700)
    cs=[store(pg,k) for k in keys(pg,'announcements/n2/comments/')]
    chk('comment uses first name only per privacy setting',len(cs)==1 and cs[0]['authorName']=='كشاف',cs)
    ev(pg,"closeModal('newsDetailModal')")
    # تفضيل الإشعارات
    settings_open(pg,'notifications'); pg.uncheck('#prefNoticePopup'); pg.wait_for_timeout(600)
    chk('notification popup preference saved',store(pg,'users/sc1')['prefs']['noticePopup'] is False)
    seed=persist_seed(pg); ctx.close()
    ctx,pg,errs,st=go(b,'sc1',extra_seed=seed); pg.wait_for_timeout(700)
    chk('popup disabled by preference (bell still available)',not pg.query_selector('.se-notice') and pg.is_visible('#notifBell'))
    # رابط مباشر لقسم + إعادة تحميل
    pg.goto('about:blank'); pg.goto(ROOT+'#settings-language'); wait_intro(pg); pg.wait_for_timeout(1500)
    chk('deep link #settings-language reopens that section after reload',ev(pg,"!document.querySelector('.set-panel[data-sec=language]').hidden && document.getElementById('settings-page').classList.contains('active-page')"))
    # كلمة المرور + عن الموقع
    pg.click('.set-panel[data-sec="language"] .set-back'); pg.click('#settingsMenu [data-sec="password"]'); pg.click('#settingsPwdBtn'); pg.wait_for_timeout(500)
    chk('password reset email requested via Firebase',ev(pg,"window.__reset")==1)
    pg.click('.set-panel[data-sec="password"] .set-back'); pg.click('#settingsMenu [data-sec="about"]'); pg.wait_for_timeout(300)
    chk('about section shows version + changelog',('11.07.v11' in pg.inner_text('#aboutVersionCode')) and 'جرس' in pg.inner_text('#changelogBox'))
    pg.click('.set-panel[data-sec="about"] .set-back')
    chk('no JS errors in settings flows',not ERR,ERR)
    # تسجيل الخروج
    pg.click('#settingsMenu [data-sec="account"]'); pg.wait_for_timeout(200)
    with pg.expect_navigation(timeout=8000):
        pg.click('#settingsLogoutBtn')
    chk('logout button works (signs out and reloads)',True)
    ctx.close()

    # ================= الوحدات =================
    ctx,pg,errs,st=go(b); close_notice(pg)
    nav(pg,'units-page'); pg.wait_for_timeout(400)
    g=ev(pg,"Array.from(document.querySelectorAll('#unitsGrid .uc')).map(c=>{const r=c.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)]})")
    chk('2 compact unit cards, equal size, not full-width on desktop',len(g)==2 and g[0]==g[1] and g[0][0]<=280,g)
    chk('cards say «اضغط هنا للتعرف على الوحدة» + have name/accent colour',all('اضغط هنا للتعرف على الوحدة' in c for c in ev(pg,"Array.from(document.querySelectorAll('#unitsGrid .uc-btn')).map(b=>b.textContent)")) and ev(pg,"getComputedStyle(document.querySelector('#unitsGrid .uc-c0')).borderTopColor")!=ev(pg,"getComputedStyle(document.querySelector('#unitsGrid .uc-c1')).borderTopColor"))
    chk('archived unit not shown','وحدة مؤرشفة' not in pg.inner_text('#unitsGrid'))
    pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(600)
    chk('unit opens as independent page (not a popup) with hash #unit-u1',ev(pg,"document.getElementById('unit-detail-page').classList.contains('active-page')") and ev(pg,"location.hash")=='#unit-u1' and not pg.is_visible('.modal-overlay[style*="flex"]'))
    t=pg.inner_text('#unitDetailBody')
    chk('detail: name, description, published leader, activities, photos',('وحدة الكشاف ألف' in t) and 'وصف الوحدة' in t and 'القائد المنشور' in t and 'تجمع قادم' in t and 'نشاط سابق' in t and ev(pg,"document.querySelectorAll('#unitDetailBody .ud-pic').length")>=1,t[:200])
    chk('detail: no private contacts shown to visitor','0550000001' not in t)
    chk('sidebar still available on unit page',(pg.click('#sidebarToggle') or True) and pg.is_visible('#navMenu') and (pg.keyboard.press('Escape') or True))
    pg.wait_for_timeout(300)
    pg.click('#unitDetailBody .ud-pic'); pg.wait_for_timeout(300)
    chk('unit photo opens in viewer',pg.is_visible('#seViewer')); pg.keyboard.press('Escape')
    pg.click('#unitBackBtn'); pg.wait_for_timeout(500)
    chk('back button returns to units page',ev(pg,"document.getElementById('units-page').classList.contains('active-page')"))
    pg.click('#unitsGrid [data-unit="u2"]'); pg.wait_for_timeout(500)
    t2=pg.inner_text('#unitDetailBody')
    chk('unit without activities shows proper empty messages (no fake data)','لا توجد برامج قادمة معلنة' in t2 and 'لا توجد أنشطة سابقة' in t2 and 'لا توجد صور' in t2)
    pg.go_back(); pg.wait_for_timeout(500)
    chk('browser back works from unit page',ev(pg,"document.getElementById('units-page').classList.contains('active-page')"),ev(pg,"location.hash"))
    pg.goto('about:blank'); pg.goto(ROOT+'#unit-u1'); wait_intro(pg); pg.wait_for_timeout(1800)
    chk('deep link #unit-u1 reopens the unit page after reload',ev(pg,"document.getElementById('unit-detail-page').classList.contains('active-page')") and 'وحدة الكشاف ألف' in pg.inner_text('#unitDetailBody'))
    ctx.close()
    ctx,pg,errs,st=go(b,'lead1'); close_notice(pg); nav(pg,'units-page'); pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(900)
    chk('active leader sees private leader contacts on unit page','0550000001' in pg.inner_text('#unitDetailBody') and 'l2@x.dz' in pg.inner_text('#unitDetailBody'))
    ctx.close()
    b.close()
summary()
