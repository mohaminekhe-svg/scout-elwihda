from h5 import *
with sync_playwright() as p:
    b=p.chromium.launch(); ctx,pg,errs,st=go(b,'admin1'); close_notice(pg)
    ev(pg,"openAnnouncementModal('add')"); pg.wait_for_timeout(500)
    pg.fill('#announcementStartAtInput','2026-11-05T10:00'); pg.click('#annTimeTools [data-h="24"]'); pg.wait_for_timeout(300)
    print(repr(pg.inner_text('#attPreview')), pg.input_value('#announcementEndAtInput'), errs)
    b.close()
