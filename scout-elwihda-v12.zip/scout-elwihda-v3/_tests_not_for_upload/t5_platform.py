import time, io
from h5 import *
RULES=open('../firestore.rules',encoding='utf-8').read()
def close_notice(pg):
    try:
        pg.wait_for_function("(()=>{const b=document.querySelector('.se-notice-close');return !b||!b.disabled})()",timeout=8000)
        if pg.query_selector('.se-notice-close'): pg.click('.se-notice-close')
        pg.wait_for_timeout(200)
        while pg.query_selector('.se-notice-close'):
            pg.wait_for_function("(()=>{const b=document.querySelector('.se-notice-close');return !b||!b.disabled})()",timeout=8000); pg.click('.se-notice-close'); pg.wait_for_timeout(200)
    except Exception as e: pass
def go(b,uid=None,vp=(1280,800),**kw):
    ctx,pg,errs,st=new_page(b,uid,vp,**kw); pg.goto(ROOT); wait_intro(pg); pg.wait_for_timeout(700); return ctx,pg,errs,st
def openmenu(pg):
    pg.click('#sidebarToggle'); pg.wait_for_timeout(450)
def nav(pg,page):
    openmenu(pg); pg.click(f'#navMenu .nav-group-btn[data-page="{page}"]'); pg.wait_for_timeout(500)
    if pg.evaluate("document.getElementById('navMenu').classList.contains('active')"):
        pg.mouse.click(40,500); pg.wait_for_timeout(450)
def store(pg,path): return pg.evaluate("p=>window.__STORE[p]||null",path)
def fill_file(pg,sel,name='t_land.jpg'): pg.set_input_files(sel,name)

with sync_playwright() as p:
    b=p.chromium.launch()

    # ============ 0) قواعد Firestore (فحوص نصية ثابتة؛ لا تغني عن Rules Playground) ============
    chk('rules: reactions doc id must equal uid & owner only',"match /reactions/{uid}" in RULES and "isOwner(uid) && isActiveUser() && postPublished" in RULES)
    chk('rules: reaction keys locked (hasOnly) and type whitelisted',"hasOnly(['uid', 'type', 'createdAt'])" in RULES and "['like', 'heart', 'clap', 'wow', 'support', 'salute']" in RULES)
    chk('rules: comments length/hidden/owner constraints',"size() <= 500" in RULES and "request.resource.data.hidden == false" in RULES and "request.resource.data.uid == request.auth.uid" in RULES)
    chk('rules: no open writes (no "allow write: if true")',"allow write: if true" not in RULES and "allow create, update, delete: if true" not in RULES)
    chk('rules: unitPrivate read only admin/active leader',"allow read: if isAdmin() || isActiveLeader();" in RULES)
    chk('rules: notifications write admin only',"match /siteNotifications/{notificationId}" in RULES and "allow create, update, delete: if isAdmin();" in RULES)
    chk('rules: user cannot change role/unit/status',"request.resource.data.role == resource.data.role" in RULES and "request.resource.data.get('unitId', '') == resource.data.get('unitId', '')" in RULES)

    # ============ 1) زائر: التنقل والشريط الجانبي ============
    ctx,pg,errs,st=go(b)
    chk('guest: no account nav items',ev(pg,"document.querySelectorAll('.nav-account-item:not([hidden])').length")==0)
    w0=ev(pg,"document.querySelector('main.main-content-viewport').getBoundingClientRect().width")
    x0=ev(pg,"document.querySelector('.royal-hero-title').getBoundingClientRect().left")
    openmenu(pg)
    w1=ev(pg,"document.querySelector('main.main-content-viewport').getBoundingClientRect().width")
    x1=ev(pg,"document.querySelector('.royal-hero-title').getBoundingClientRect().left")
    chk('sidebar opens as overlay: content width/position unchanged',abs(w0-w1)<1 and abs(x0-x1)<1 and pg.is_visible('#navMenu'),(w0,w1,x0,x1))
    labels=ev(pg,"Array.from(document.querySelectorAll('#navMenu > li > .nav-group-btn, #navMenu .nav-group > .nav-group-btn')).filter(b=>b.offsetParent).map(b=>b.textContent.trim().replace(/\\s+/g,' '))")
    for want in ['الرئيسية','آخر الأخبار','البرنامج الكشفي القادم','الإعلانات','الوحدات الكشفية','المعرض الكشفي','المهارات الكشفية','التعريف بالفوج']:
        chk('guest nav has: '+want,any(want in l for l in labels),labels)
    chk('guest nav has no admin/profile items',not any(('الملف الشخصي' in l or 'تسجيل الخروج' in l or 'بطاقتي' in l) for l in labels))
    pg.mouse.click(60,400); pg.wait_for_timeout(500)
    chk('backdrop click closes sidebar (desktop)',not pg.is_visible('#navMenu'))
    openmenu(pg); pg.keyboard.press('Escape'); pg.wait_for_timeout(500)
    chk('Escape closes sidebar (desktop)',not pg.is_visible('#navMenu'))
    # الإشعارات للزائر
    close_notice(pg)
    # ============ 2) الإشعارات (زائر) ============
    ctx2,pg2,errs2,_=go(b)
    pg2.wait_for_timeout(600)
    chk('notice shown for guest (active, audience all)',pg2.is_visible('.se-notice') and 'فتح التسجيلات' in pg2.inner_text('.se-notice'))
    chk('notice shows issuer role and name','قائد الفوج' in pg2.inner_text('.se-notice') and 'الأستاذ فلان' in pg2.inner_text('.se-notice'))
    chk('notice close disabled at first',pg2.is_disabled('.se-notice-close'))
    pg2.click('.se-notice-close',force=True,timeout=1000) if False else None
    pg2.wait_for_timeout(1200)
    chk('notice still disabled before delay ends',pg2.is_disabled('.se-notice-close'))
    pg2.wait_for_timeout(2600)
    chk('notice close enabled after delay',not pg2.is_disabled('.se-notice-close'))
    pg2.click('.se-notice-close'); pg2.wait_for_timeout(300)
    chk('members-only/expired/hidden notices not shown to guest',not pg2.query_selector('.se-notice') or all(t not in pg2.inner_text('.se-notice') for t in ['منتهٍ','مخفي','للأعضاء']))
    chk('notice does not block site (page usable)',pg2.is_enabled('#sidebarToggle'))
    ctx2.close()
    # عضو: إشعار الأعضاء
    ctx2,pg2,errs2,_=go(b,'sc1'); pg2.wait_for_timeout(600)
    seen=[]
    for _i in range(3):
        t=pg2.inner_text('.se-notice') if pg2.query_selector('.se-notice') else ''
        if t: seen.append(t)
        close_notice(pg2) if False else None
        try:
            pg2.wait_for_function("(()=>{const b=document.querySelector('.se-notice-close');return !b||!b.disabled})()",timeout=8000)
            if pg2.query_selector('.se-notice-close'): pg2.click('.se-notice-close'); pg2.wait_for_timeout(300)
        except Exception: break
    chk('member sees members-only notice',any('للأعضاء' in s for s in seen),seen)
    ctx2.close()

    # ============ 3) الوحدات (عام) ============
    nav(pg,'units-page')
    chk('units grid shows active units only (2 cards)',ev(pg,"document.querySelectorAll('#unitsGrid .uc').length")==2)
    chk('units cards in responsive grid (same row on desktop)',ev(pg,"(()=>{const c=[...document.querySelectorAll('#unitsGrid .uc')].map(x=>x.getBoundingClientRect().top);return Math.abs(c[0]-c[1])<5})()"))
    pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(500)
    t=pg.inner_text('#unitDetailBody')
    chk('unit detail (independent page) shows published leader name',('القائد المنشور' in t))
    chk('guest does NOT see private leader contacts',('0550000001' not in t) and ('l1@x.dz' not in t))
    pg.click('#unitBackBtn'); pg.wait_for_timeout(300)
    ctx.close()
    # قائد نشط يرى بيانات الاتصال الخاصة
    ctx,pg,errs,st=go(b,'lead1'); close_notice(pg)
    nav(pg,'units-page'); pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(700)
    t=pg.inner_text('#unitDetailBody')
    chk('active leader sees 3 leaders private contacts','0550000001' in t and 'l2@x.dz' in t and 'القائد الثاني' in t and 'القائد الثالث' not in t.split('بيانات الاتصال')[0] or ('القائد الأول' in t),t[:300])
    ctx.close()
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg)
    nav(pg,'units-page'); pg.click('#unitsGrid [data-unit="u1"]'); pg.wait_for_timeout(700)
    chk('scout does NOT see private contacts','0550000001' not in pg.inner_text('#unitDetailBody'))
    ctx.close()

    b.close()
summary()
