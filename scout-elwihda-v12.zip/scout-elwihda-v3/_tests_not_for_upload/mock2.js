/* محاكي Firebase ذو حالة — لاختبار منطق الواجهة فقط (ليس Emulator ولا يثبت القواعد الحقيقية).
   يقلّد باختصار قواعد firestore.rules الجديدة ليكشف أي حمولة يرفضها الخادم عادةً. */
(function(){
  var DB = window.__STORE = window.__STORE || {};   // path -> data
  var listeners = [];
  var WRITES = window.__writes = [];
  var DENIED = window.__denied = [];
  var now = Date.now, DAY = 86400000;
  function ts(ms){ return {__ts:ms, toMillis:function(){return ms}, toDate:function(){return new Date(ms)}, seconds: Math.floor(ms/1000)}; }
  var SERVER_TS = {__sentinel:'ts'};
  function resolve(d, existing){
    var o={}; Object.keys(d).forEach(function(k){
      var v=d[k];
      if(v&&v.__sentinel==='ts') o[k]=ts(now());
      else if(v&&v.__sentinel==='inc') o[k]=((existing&&existing[k])||0)+v.n;
      else if(v&&v.__sentinel==='del') {}
      else o[k]=v;
    }); return o;
  }
  var user = null;          // {uid,email}
  function me(){ return user ? DB['users/'+user.uid] : null; }
  function role(){ var m=me(); return m && m.role; }
  function isAdmin(){ return role()==='admin'; }
  function active(){ var m=me(); return !!m && m.accountStatus==='active'; }
  function pub(aid){ var a=DB['announcements/'+aid]; return !!a && a.published===true; }
  function tsEq(v){ return v && v.__ts!=null; }
  // تقليد القواعد (create/update/delete) للمسارات الجديدة والحساسة
  function allow(op, path, data, existing){
    var p=path.split('/'), col=p[0];
    if(!user && !(col==='securityEvents')) { if(op==='read') return true; }
    if(isAdmin()){ if(col==='adminLogs'&&(op==='update'||op==='delete')) return false; if(col==='backups'&&op!=='read') return false; if(col==='announcements'&&p[2]==='comments'&&p[4]==='officialLike'&&false) return false; return true; }
    var uid=user&&user.uid;
    if(col==='adminLogs'){ if(op==='read') return isAdmin(); if(op==='create') return !!user&&(isAdmin()||['media_manager','leader'].indexOf(role())>=0&&active())&&data.actorUid===uid&&tsEq(data.createdAt); return false; }
    if(col==='supportTickets'){
      if(op==='read') return !!existing&&existing.uid===uid;
      if(op==='create') return active()&&data.uid===uid&&data.status==='new'&&['account','upload','content','bug','other'].indexOf(data.type)>=0&&data.title.length>=3&&data.description.length>=5&&tsEq(data.createdAt);
      return false; }
    if(col==='backups') return false;
    if(col==='users' && p.length===4 && p[2]==='inbox'){ if(op==='read'||op==='delete') return uid===p[1]; return false; }
    if(col==='announcements' && p.length===6 && p[4]==='officialLike'){ if(op==='read') return pub(p[1]); return false; }
    if(col==='announcements' && p.length===6 && p[4]==='likes'){
      if(op==='read') return !!user; if(op==='delete') return uid===p[5];
      return uid===p[5]&&active()&&pub(p[1])&&Object.keys(data).sort().join(',')==='createdAt,uid'&&data.uid===uid&&tsEq(data.createdAt); }
    if(col==='announcements' && p.length===4 && p[2]==='reactions'){
      if(op==='read') return pub(p[1]);
      if(op==='delete') return uid===p[3];
      if(!(uid===p[3] && active() && pub(p[1]))) return false;
      var k=Object.keys(data).sort().join(',');
      return k==='createdAt,type,uid' && data.uid===uid && ['like','heart','clap','wow','support','salute'].indexOf(data.type)>=0 && tsEq(data.createdAt);
    }
    if(col==='announcements' && p.length===4 && p[2]==='comments'){
      if(op==='read') return !!user && ((existing&&existing.hidden===false&&pub(p[1])) || (existing&&existing.uid===uid));
      if(op==='delete') return existing && existing.uid===uid;
      if(op==='create'){
        var k2=Object.keys(data).filter(function(x){return x!=='parentId'}).sort().join(',');
        return active()&&pub(p[1])&&k2==='authorName,createdAt,hidden,text,uid'&&data.uid===uid&&typeof data.text==='string'&&data.text.length>=1&&data.text.length<=500&&data.hidden===false&&tsEq(data.createdAt);
      }
      if(op==='update'){ return active()&&existing&&existing.uid===uid&&data.text&&data.text.length>=1&&data.text.length<=500; }
    }
    if(col==='announcements' && p.length===4 && p[2]==='saves'){
      if(op==='read') return !!user;
      if(op==='delete') return uid===p[3];
      return uid===p[3]&&active()&&pub(p[1])&&Object.keys(data).sort().join(',')==='savedAt,uid'&&data.uid===uid&&tsEq(data.savedAt);
    }
    if(col==='users' && p.length===4 && p[2]==='notificationStates'){
      if(uid!==p[1]) return false; if(op==='read'||op==='delete') return true;
      return active()&&Object.keys(data).sort().join(',')==='status,updatedAt'&&['read','later'].indexOf(data.status)>=0&&tsEq(data.updatedAt);
    }
    if(col==='users' && p.length===4 && p[2]==='saved'){
      if(uid!==p[1]) return false; if(op==='read'||op==='delete') return true;
      return active()&&Object.keys(data).sort().join(',')==='postId,savedAt'&&data.postId===p[3];
    }
    if(col==='users' && p.length===2 && op==='read') return !!user && (isAdmin()||uid===p[1]);
    if(col==='users' && p.length===2){
      if(op==='update'){ if(uid!==p[1]) return false;
        var m=DB[path]; return data.role===m.role && data.accountStatus===m.accountStatus && (data.unitId||'')===(m.unitId||'') && (data.unit||'')===(m.unit||'') && JSON.stringify(data.permissions||null)===JSON.stringify(m.permissions||null); }
      if(op==='create') return uid===p[1] && ['scout','parent','leader'].indexOf(data.role)>=0 && !data.permissions;
    }
    if(col==='siteNotifications' && op!=='read') return false;
    if(col==='units'&&op==='update'&&role()==='leader'&&active()&&me().unitId===p[1]){ var ex=existing||{},ok=['description','imageUrl','driveFileId','imageName','pub','publishNames','publishContacts','manualScoutCount','updatedAt']; var ch=Object.keys(data).filter(function(k){return JSON.stringify(data[k])!==JSON.stringify(ex[k])}); return ch.every(function(k){return ok.indexOf(k)>=0}); }
    if(col==='unitPrivate'&&op!=='read'&&role()==='leader'&&active()&&me().unitId===p[1]&&op!=='delete') return true;
    if(col==='units'||col==='unitPrivate'||col==='activities'){ if(op!=='read') return false; }
    if(col==='unitChangeRequests'){ if(op==='create') return active()&&p[1]===uid&&data.status==='pending'; }
    if(col==='announcements' && p.length===2 && op!=='read') return false;
    return op==='read' ? true : false;
  }
  function deny(op,path){ var e=new Error('Missing or insufficient permissions.'); e.code='permission-denied'; DENIED.push(op+':'+path); return e; }
  function listFor(colPath){
    var out=[]; Object.keys(DB).forEach(function(k){
      if(k.indexOf(colPath+'/')===0 && k.slice(colPath.length+1).indexOf('/')<0) out.push(k);
    }); return out;
  }
  function getv(d,f){ return f.split('.').reduce(function(a,k){return a==null?a:a[k]},d); }
  function mkSnap(path){ var d=DB[path]; return {id:path.split('/').pop(), exists:d!==undefined, data:function(){return d===undefined?undefined:JSON.parse(JSON.stringify(d,function(k,v){return v}))&&d}, ref:docRef(path)}; }
  function docRef(path){
    var r={path:path,id:path.split('/').pop(),
      get:function(){ if(!allow('read',path,null,DB[path])) return Promise.reject(deny('read',path)); return Promise.resolve(mkSnap(path)); },
      set:function(data,opt){ var ex=DB[path]; var op=ex?'update':'create'; var nd=resolve(data,ex); if(opt&&opt.merge&&ex) nd=Object.assign({},ex,nd);
        if(!allow(op,path,nd,ex)) return Promise.reject(deny(op,path)); DB[path]=nd; WRITES.push(['set',path,nd]); fire(); return Promise.resolve(); },
      update:function(data){ var ex=DB[path]; if(!ex) return Promise.reject(Object.assign(new Error('not-found'),{code:'not-found'}));
        var nd=Object.assign({},ex,resolve(data,ex)); Object.keys(data).forEach(function(k){ if(data[k]&&data[k].__sentinel==='del') delete nd[k]; });
        if(!allow('update',path,nd,ex)) return Promise.reject(deny('update',path)); DB[path]=nd; WRITES.push(['update',path,nd]); fire(); return Promise.resolve(); },
      delete:function(){ if(!allow('delete',path,null,DB[path])) return Promise.reject(deny('delete',path)); delete DB[path]; WRITES.push(['delete',path]); fire(); return Promise.resolve(); },
      collection:function(c){ return colRef(path+'/'+c); },
      onSnapshot:function(cb,eb){ var l={run:function(){ if(!allow('read',path,null,DB[path])){ if(eb) eb(deny('read',path)); return;} cb(mkSnap(path)); }}; listeners.push(l); setTimeout(l.run,0); return function(){ listeners=listeners.filter(function(x){return x!==l}); }; }
    }; return r;
  }
  function query(colPath, filters, orders, lim){
    var q={
      where:function(f,op,v){ return query(colPath,filters.concat([[f,op,v]]),orders,lim); },
      orderBy:function(f,dir){ return query(colPath,filters,orders.concat([[f,dir||'asc']]),lim); },
      limit:function(n){ return query(colPath,filters,orders,n); },
      _run:function(){
        var RESTR={adminLogs:'a',backups:'a',users:'au',supportTickets:'au'};
        if(RESTR[colPath] && !isAdmin()){ var okq=RESTR[colPath]==='au' && user && filters.some(function(f){return f[0]==='uid'&&f[1]==='=='&&f[2]===user.uid}); if(!okq) return {err:deny('read',colPath)}; }
        var keys=listFor(colPath), docs=keys.map(function(k){return {k:k,d:DB[k]}}).filter(function(x){
          return filters.every(function(f){ var v=getv(x.d,f[0]); var t=v&&v.__ts!=null?v.__ts:v, w=f[2]&&f[2].__ts!=null?f[2].__ts:f[2];
            if(f[1]==='==') return v===f[2]; if(f[1]==='in') return f[2].indexOf(v)>=0; if(f[1]==='>=') return t>=w; if(f[1]==='<=') return t<=w; if(f[1]==='>') return t>w; if(f[1]==='<') return t<w; if(f[1]==='!=') return v!==f[2]; return true; });});
        orders.slice().reverse().forEach(function(o){ docs.sort(function(a,b){ var x=getv(a.d,o[0]),y=getv(b.d,o[0]); x=x&&x.__ts!=null?x.__ts:x; y=y&&y.__ts!=null?y.__ts:y; return (x>y?1:x<y?-1:0)*(o[1]==='desc'?-1:1); }); });
        if(lim) docs=docs.slice(0,lim);
        // فحص القراءة: كل وثيقة يجب أن تكون مسموحة (يقلّد رفض الاستعلام كاملاً)
        for(var i=0;i<docs.length;i++){ if(!allow('read',docs[i].k,null,docs[i].d)) return {err:deny('read',docs[i].k)}; }
        var arr=docs.map(function(x){return mkSnap(x.k)});
        return {snap:{empty:!arr.length,size:arr.length,docs:arr,forEach:function(f){arr.forEach(f)},docChanges:function(){return []}}};
      },
      get:function(){ var r=q._run(); return r.err?Promise.reject(r.err):Promise.resolve(r.snap); },
      onSnapshot:function(cb,eb){ var l={run:function(){ var r=q._run(); if(r.err){ if(eb) eb(r.err); else console.error('listener denied'); } else cb(r.snap); }}; listeners.push(l); setTimeout(l.run,0); return function(){ listeners=listeners.filter(function(x){return x!==l}); }; }
    }; return q;
  }
  function colRef(path){ var q=query(path,[],[],0); q.doc=function(id){ id=id||('g'+Math.random().toString(36).slice(2,10)); return docRef(path+'/'+id); };
    q.add=function(data){ var r=q.doc(); return r.set(data).then(function(){return r}); }; q.id=path.split('/').pop(); q.path=path; return q; }
  function fire(){ setTimeout(function(){ listeners.slice().forEach(function(l){ try{l.run()}catch(e){console.error(e)} }); },0); }
  var fsfn=function(){ return {
    collection:colRef, doc:docRef,
    batch:function(){ var ops=[]; return {
      set:function(r,d,o){ops.push(function(){return r.set(d,o)}); return this}, update:function(r,d){ops.push(function(){return r.update(d)}); return this}, delete:function(r){ops.push(function(){return r.delete()}); return this},
      commit:function(){ return ops.reduce(function(p,f){return p.then(f)},Promise.resolve()); } }; },
    runTransaction:function(fn){ return fn({get:function(r){return r.get()},set:function(r,d){return r.set(d)},update:function(r,d){return r.update(d)},delete:function(r){return r.delete()}}); },
    enablePersistence:function(){return Promise.resolve()}, settings:function(){} }; };
  fsfn.FieldValue={serverTimestamp:function(){return SERVER_TS},increment:function(n){return {__sentinel:'inc',n:n}},delete:function(){return {__sentinel:'del'}},arrayUnion:function(){return []}};
  fsfn.Timestamp={fromMillis:ts,fromDate:function(d){return ts(d.getTime())},now:function(){return ts(now())}};
  // ---------- Auth ----------
  var authCbs=[];
  var authObj={ get currentUser(){ return user?{uid:user.uid,email:user.email,getIdToken:function(){return Promise.resolve('x'.repeat(120))},delete:function(){return Promise.resolve()},updateProfile:function(){return Promise.resolve()},reload:function(){return Promise.resolve()}}:null; },
    onAuthStateChanged:function(cb){ authCbs.push(cb); setTimeout(function(){ cb(authObj.currentUser); },0); return function(){}; },
    signOut:function(){ user=null; authCbs.forEach(function(c){c(null)}); return Promise.resolve(); },
    setPersistence:function(){return Promise.resolve()},
    sendPasswordResetEmail:function(e){ window.__reset=(window.__reset||0)+1; window.__resetEmail=e; return Promise.resolve(); },
    useDeviceLanguage:function(){},
    signInWithEmailAndPassword:function(e){ var uid=window.__EMAIL2UID&&window.__EMAIL2UID[e]; if(!uid) return Promise.reject(Object.assign(new Error('x'),{code:'auth/user-not-found'})); user={uid:uid,email:e}; authCbs.forEach(function(c){c(authObj.currentUser)}); return Promise.resolve({user:authObj.currentUser}); }
  };
  window.__signInAs=function(uid){ var m=DB['users/'+uid]; user={uid:uid,email:(m&&m.email)||''}; authCbs.forEach(function(c){c(authObj.currentUser)}); };
  window.__signOut=function(){ authObj.signOut(); };
  var af=function(){return authObj}; af.Auth={Persistence:{LOCAL:'l',SESSION:'s',NONE:'n'}};
  window.firebase={initializeApp:function(){return {name:'x'}},apps:[],app:function(){return {}},auth:af,firestore:fsfn,storage:function(){return {}}};
  // تهيئة اختيارية قبل التحميل: window.__SEED() تُعرَّف من الاختبار قبل هذا الملف
  if(window.__SEED) window.__SEED(DB, ts);
  if(window.__LOGIN_UID){ user={uid:window.__LOGIN_UID,email:(DB['users/'+window.__LOGIN_UID]||{}).email||''}; }
  window.__ts=ts; window.__fire=fire;
})();
