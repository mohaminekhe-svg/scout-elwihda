from h5 import *
with sync_playwright() as p:
    b=p.chromium.launch()
    # ================= الوحدات: أدمن CRUD + رفع صورة =================
    ctx,pg,errs,st=go(b,'admin1'); close_notice(pg)
    ev(pg,"V3.loadAdminUnits()"); pg.wait_for_timeout(500)
    chk('admin sees all units in admin list (incl. archived)',ev(pg,"document.querySelectorAll('#unitsAdminList .v3-admin-row').length")==3)
    # إنشاء
    ev(pg,"V3.openUnitForm()"); pg.wait_for_timeout(300)
    pg.fill('#unitName','وحدة الشبل المبتدئ'); pg.fill('#unitDesc','وصف قصير')
    for n,(a,b_,c) in enumerate([('قائد أول','0550111111','a@x.dz'),('قائد ثان','0550222222','b@x.dz'),('قائد ثالث','0550333333','c@x.dz')],1):
        pg.fill(f'#ul{n}Name',a); pg.fill(f'#ul{n}Phone',b_); pg.fill(f'#ul{n}Email',c)
    pg.check('#unitPublishNames')
    fill_file=lambda sel,f: pg.set_input_files(sel,f)
    fill_file('#unitImageUploader input[type=file]','bad.txt'); pg.wait_for_timeout(200)
    chk('uploader rejects non-image file',('غير مدعوم' in pg.inner_text('#unitImageUploader .se-up-msg')) and not pg.query_selector('#unitImageUploader .se-up-prev img'))
    fill_file('#unitImageUploader input[type=file]','t_port.png'); pg.wait_for_timeout(300)
    chk('uploader shows preview before upload',bool(pg.query_selector('#unitImageUploader .se-up-prev img')))
    chk('nothing uploaded before save',len(st['uploads'])==0)
    pg.click('#unitFormSubmit'); pg.wait_for_timeout(1500)
    chk('upload sent once to Apps Script with idToken and kind',len(st['uploads'])==1 and st['uploads'][0].get('kind')=='announcements' and len(st['uploads'][0].get('idToken',''))>50 and st['uploads'][0].get('action')=='upload')
    chk('upload payload has no secrets (no password/secret fields)',not any(k in st['uploads'][0] for k in ['secretToken','password','apiKey']))
    ids=[k for k in keys(pg,'units/') if store(pg,k)['name']=='وحدة الشبل المبتدئ']
    chk('unit created in Firestore after successful upload',len(ids)==1)
    u=store(pg,ids[0]); uid_=ids[0].split('/')[1]
    chk('unit stores Drive imageUrl+driveFileId (not fake)',u.get('driveFileId','').startswith('UP01') and 'drive.google.com/thumbnail?id=UP01' in u.get('imageUrl',''),u)
    pv=store(pg,'unitPrivate/'+uid_)
    chk('private doc has 3 leaders with emails',pv and len(pv['leaders'])==3 and pv['leaders'][2]['email']=='c@x.dz')
    chk('public doc has names only (no phones/emails) when only names published',u['pub']['leaders'][0].get('name')=='قائد أول' and 'phone' not in u['pub']['leaders'][0] and 'email' not in u['pub']['leaders'][0])
    chk('unit modal closed + list refreshed',not pg.is_visible('#unitFormModal') and ev(pg,"document.querySelectorAll('#unitsAdminList .v3-admin-row').length")==4)
    # تعديل (بدون تغيير الصورة ⇒ لا رفع جديد)
    ev(pg,f"V3.openUnitForm('{uid_}')"); pg.wait_for_timeout(500)
    chk('edit form loads private leaders',pg.input_value('#ul2Phone')=='0550222222')
    pg.fill('#unitName','وحدة الشبل (معدلة)'); pg.check('#unitPublishContacts'); pg.click('#unitFormSubmit'); pg.wait_for_timeout(900)
    chk('edit saved without re-uploading image',len(st['uploads'])==1 and store(pg,'units/'+uid_)['name']=='وحدة الشبل (معدلة)' and store(pg,'units/'+uid_)['driveFileId'].startswith('UP01'))
    chk('contacts published only after explicit checkbox',store(pg,'units/'+uid_)['pub']['leaders'][0].get('phone')=='0550111111')
    # فشل الرفع ⇒ لا حفظ في Firestore
    st['fail']=True
    before=len(keys(pg,'units/'))
    ev(pg,"V3.openUnitForm()"); pg.wait_for_timeout(200); pg.fill('#unitName','وحدة فاشلة'); fill_file('#unitImageUploader input[type=file]','t_land.jpg'); pg.click('#unitFormSubmit'); pg.wait_for_timeout(1500)
    chk('failed upload: clear error + nothing saved',('تعذّر رفع الصورة' in pg.inner_text('#unitFormError')) and len(keys(pg,'units/'))==before and pg.is_visible('#unitFormModal'))
    st['fail']=False; pg.click('#unitFormSubmit'); pg.wait_for_timeout(1500)
    chk('retry after failure succeeds (single doc added)',len(keys(pg,'units/'))==before+1)
    pg.evaluate("closeModal('unitFormModal')")
    # أرشفة + حذف بتأكيد
    DLG={'m':'dismiss'}
    pg.on('dialog',lambda d: d.accept() if DLG['m']=='accept' else d.dismiss())
    ev(pg,"V3.loadAdminUnits()"); pg.wait_for_timeout(400)
    row=pg.locator(f'#unitsAdminList .v3-admin-row[data-id="{uid_}"]')
    DLG['m']='dismiss'; row.locator('button[data-a="del"]').evaluate('e=>e.click()'); pg.wait_for_timeout(700)
    chk('delete cancelled by dialog keeps unit',store(pg,'units/'+uid_) is not None)
    DLG['m']='accept'; row.locator('button[data-a="del"]').evaluate('e=>e.click()'); pg.wait_for_timeout(900)
    chk('delete confirmed removes unit and private doc',store(pg,'units/'+uid_) is None and store(pg,'unitPrivate/'+uid_) is None)
    DLG['m']='dismiss'
    pg.locator('#unitsAdminList .v3-admin-row[data-id="u1"] button[data-a="del"]').evaluate('e=>e.click()'); pg.wait_for_timeout(700)
    chk('unit linked to users cannot be deleted',store(pg,'units/u1') is not None)
    # تشخيص
    pg.evaluate("V5.runUnitsDiagnostics()"); pg.wait_for_timeout(1500)
    d=pg.inner_text('#unitsDiagOut')
    chk('diagnostics: role admin ok + write probe ok',('role في Firestore = "admin"' in d) and ('كتابة تجريبية في units نجحت' in d) and not [k for k in keys(pg,'units/') if '__diag' in k],d)
    # صلاحيات: دور تغيّر في الخادم بعد تحميل الواجهة ⇒ رسالة permission-denied واضحة
    ev(pg,"window.__STORE['users/admin1'].role='leader'")
    ev(pg,"V3.openUnitForm()"); pg.wait_for_timeout(200); pg.fill('#unitName','ممنوعة'); pg.click('#unitFormSubmit'); pg.wait_for_timeout(900)
    chk('permission-denied gives actionable Arabic message',('permission-denied' in pg.inner_text('#unitFormError')) and ('firestore.rules' in pg.inner_text('#unitFormError')),pg.inner_text('#unitFormError'))
    chk('no unit saved when denied',not [k for k in keys(pg,'units/') if store(pg,k)['name']=='ممنوعة'])
    pg.evaluate("window.__STORE['users/admin1'].role='admin'"); pg.evaluate("closeModal('unitFormModal')")
    pg.evaluate("V5.runUnitsDiagnostics()")
    # فتح تفاصيل وحدة بصورة Drive
    ctx.close()
    # غير الأدمن لا يحفظ
    ctx,pg,errs,st=go(b,'sc1'); close_notice(pg)
    chk('non-admin: diagnostics/admin not reachable but V3 form refuses',ev(pg,"(()=>{V3.openUnitForm();document.getElementById('unitName').value='x';document.getElementById('unitForm').requestSubmit();return true})()"))
    pg.wait_for_timeout(500)
    chk('non-admin cannot create unit',not [k for k in keys(pg,'units/') if store(pg,k)['name']=='x'])
    ctx.close()

    # ================= رفع الصور: ذاكرة مؤقتة وأنواع =================
    ctx,pg,errs,st=go(b,'admin1'); close_notice(pg)
    r=ev(pg,"""(async()=>{const h=document.createElement('div');document.body.appendChild(h);window.__c=SEImage.mount(h,{kind:'gallery'});return true})()""")
    pg.set_input_files('div:last-of-type input[type=file]','t_sq.webp') if False else None
    inp=pg.locator('body > div:last-of-type input[type=file]'); inp.set_input_files('t_sq.webp'); pg.wait_for_timeout(300)
    a1=ev(pg,"window.__c.commit().then(r=>r)"); a2=ev(pg,"window.__c.commit().then(r=>r)")
    chk('same file committed twice uploads once (no duplicates on retry)',len(st['uploads'])==1 and a1==a2,(len(st['uploads']),a1,a2))
    big=b'0'*(13*1024*1024)
    inp.set_input_files(files=[{'name':'huge.jpg','mimeType':'image/jpeg','buffer':big}]); pg.wait_for_timeout(300)
    chk('oversize image rejected with message',('كبير' in pg.inner_text('body > div:last-of-type .se-up-msg')))
    ctx.close()
    b.close()
summary()
