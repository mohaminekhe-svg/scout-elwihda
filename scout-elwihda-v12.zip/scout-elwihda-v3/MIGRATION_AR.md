# خطة الترحيل الآمن لقاعدة البيانات (إضافات فقط — لا حذف ولا إعادة تسمية)

## ما يتغير في Firestore
**كله إضافات**؛ لا يُحذف حقل ولا مجموعة ولا يُعاد تسمية شيء، فتبقى بيانات الحسابات والمنشورات والصور والتعليقات الحالية صالحة كما هي.

| العنصر | النوع | ملاحظة |
|---|---|---|
| `users/{uid}.bloodType` | حقل اختياري جديد | القيمة من القائمة الثابتة أو فارغة؛ الوثائق القديمة بدونه تعمل |
| `users/{uid}.nickname/birthDate/birthPlace/prefs/language` | حقول اختيارية (من المرحلة السابقة) | |
| `users/{uid}/inbox/{id}` | مجموعة فرعية جديدة | إشعارات شخصية يكتبها قائد الفوج فقط |
| `users/{uid}/notificationStates/{id}`, `users/{uid}/saved/{id}` | مجموعات فرعية (سابقة) | |
| `announcements/{id}/comments/{cid}.parentId` | حقل اختياري جديد | الردود؛ التعليقات القديمة بلا parentId تُعامل كتعليقات رئيسية |
| `announcements/{id}/comments/{cid}/likes/{uid}` و`/officialLike/leader` | مجموعات فرعية جديدة | |
| `adminLogs`, `supportTickets`, `backups`, `unitChangeRequests`, `siteNotifications` | مجموعات جديدة | ما عدا `backups` تكتبها الواجهة وفق القواعد؛ `backups` تكتبها Cloud Functions فقط |
| `units`/`unitPrivate`/`activities` | لا تغيير في الشكل | القواعد فقط تسمح لقائد الوحدة بوحدته |

**لا حاجة إلى سكربت ترحيل بيانات.** الأدوار الحالية بقيت كما هي: `admin` = قائد الفوج، `leader` = قائد وحدة (مع `unitId`)، `media_manager` أو `leader` بعنوان «مسؤول إعلام» = فريق الإعلام، `scout`، `parent`.

## خطوات آمنة قبل التطبيق
1. من Firebase Console ← Firestore ← **Export** (أو Cloud Firestore Backups) لأخذ نسخة كاملة قبل نشر القواعد الجديدة. احتفظ بملف القواعد القديم (`firestore.rules` الحالي في موقعك).
2. انشر `firestore.rules` الجديد، ثم اختبر في **Rules Playground** (انظر REPORT_AR.md).
3. ارفع ملفات الموقع الجديدة.

## التراجع (Rollback)
- ملفات الموقع: أعد رفع النسخة الاحتياطية من cPanel.
- القواعد: انشر ملف القواعد القديم (يمكنك العودة إليه من سجل الإصدارات في Firebase Console ← Rules).
- البيانات: الحقول والمجموعات الجديدة تتجاهلها النسخة القديمة من الموقع، فلا يلزم حذفها.
