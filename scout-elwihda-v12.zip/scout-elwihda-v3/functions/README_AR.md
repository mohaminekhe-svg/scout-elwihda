# وظائف الخادم (Cloud Functions) — البريد والنسخ الاحتياطي

> هذه الوظائف **غير منشورة افتراضيًا ولم تُختبر على Firebase الحي**. بدونها يعمل الموقع كاملًا ما عدا: إرسال البريد من لوحة الإدارة، والنسخ الاحتياطي/الاستعادة (تظهر رسالة واضحة بأنها غير مُعدّة).

## المتطلبات
1. مشروع Firebase على **خطة Blaze** (مطلوبة لـ Cloud Functions وStorage وخروج الشبكة إلى SMTP).
2. تفعيل **Firebase Storage** (حاوية النسخ الاحتياطية، مسار `backups/`). قواعد Storage الحالية في المشروع تمنع الوصول العام؛ اترك الحاوية خاصة (الوظائف تستعمل صلاحيات الخادم).
3. حساب بريد SMTP (مزوّد الاستضافة أو أي خدمة) — **لا تضع بياناته في ملفات الموقع**.

## الإعداد
```bash
npm i -g firebase-tools
firebase login
cd functions && npm install && cd ..
firebase functions:secrets:set SMTP_HOST      # مثال: mail.yourdomain.dz
firebase functions:secrets:set SMTP_PORT      # 465 أو 587
firebase functions:secrets:set SMTP_USER
firebase functions:secrets:set SMTP_PASS
firebase functions:secrets:set MAIL_FROM      # "فوج الوحدة <no-reply@yourdomain.dz>"
firebase deploy --only functions
firebase deploy --only firestore:rules
```
(يجب أن يكون ملف `firebase.json` عندك يشير إلى المجلد `functions`.)

## ما تفعله كل وظيفة
- `sendAdminEmail`: تتحقق أن المستدعي قائد الفوج (من Firestore على الخادم)، تقبل **معرّف المستخدم** لا عنوانًا حرًا (فلا تُستعمل كمرحّل بريد)، تتحقق من الطول، تحدّ **10 رسائل/ساعة**، تُرجع `ok:true` فقط بعد نجاح SMTP، وتسجّل النتيجة في `adminLogs`.
- `createBackup`: تصدّر المجموعات: users, leaders, units, unitPrivate, activities, announcements (+تعليقات/تفاعلات/حفظ), siteNotifications, supportTickets, settings, gallery إلى ملف JSON في Storage مع بصمة SHA-256، وتحذف أي حقل اسمه يشبه secret/token/password.
- `getBackupDownloadUrl`: رابط تنزيل موقّع صالح 5 دقائق.
- `restoreBackup`: تتحقق من البصمة والصيغة **قبل** أي كتابة، تنشئ **نسخة أمان** من الحالة الحالية، ثم **تدمج** (merge) دون حذف أي وثيقة.

## ما لا يُنسخ (بصراحة)
حسابات Firebase Authentication وكلمات المرور (لا يمكن ولا يجب)، ملفات الصور في Google Drive (انسخ المجلد يدويًا من Drive)، سجل النشاطات `adminLogs`، وبيانات النسخ نفسها. الاستعادة لا تُعيد حذف ما حُذف بعد النسخة (دمج فقط).
