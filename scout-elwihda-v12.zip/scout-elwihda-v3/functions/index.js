/**
 * Scout Elwihda — Cloud Functions (غير منشورة افتراضيًا؛ تتطلب خطة Blaze وإعداد الأسرار).
 * كل الدوال تتحقق من أن المستدعي «قائد الفوج» (users/{uid}.role == "admin" و accountStatus == "active") من جهة الخادم.
 * لا أسرار في الكود: SMTP تُحفظ في Secret Manager (firebase functions:secrets:set ...).
 */
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

admin.initializeApp();
const db = admin.firestore();

const SMTP_HOST = defineSecret('SMTP_HOST');
const SMTP_PORT = defineSecret('SMTP_PORT');
const SMTP_USER = defineSecret('SMTP_USER');
const SMTP_PASS = defineSecret('SMTP_PASS');
const MAIL_FROM = defineSecret('MAIL_FROM'); // مثال: "فوج الوحدة <no-reply@yourdomain.dz>"

// ---------------------------------------------------------------- مساعدات
async function requireGroupLeader(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول.');
  const snap = await db.collection('users').doc(request.auth.uid).get();
  const u = snap.exists ? snap.data() : null;
  if (!u || u.role !== 'admin' || u.accountStatus === 'suspended' || u.accountStatus === 'locked') {
    throw new HttpsError('permission-denied', 'هذه العملية لقائد الفوج فقط.');
  }
  return { uid: request.auth.uid, name: u.fullName || u.email || 'قائد الفوج' };
}
async function writeLog(actor, action, targetType, targetId, targetLabel, result) {
  await db.collection('adminLogs').add({
    actorUid: actor.uid, actorName: String(actor.name).slice(0, 80), actorRole: 'قائد الفوج',
    action, targetType, targetId: String(targetId || ''), targetLabel: String(targetLabel || '').slice(0, 120),
    result: String(result || 'ok').slice(0, 120), createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
}
const SENSITIVE = /(secret|token|password|passwd|apikey|api_key|private)/i;
function serialize(v) {
  if (v && typeof v.toMillis === 'function') return { __ts: v.toMillis() };
  if (Array.isArray(v)) return v.map(serialize);
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) { if (SENSITIVE.test(k)) continue; o[k] = serialize(v[k]); } return o; }
  return v;
}
function revive(v) {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    if (Object.keys(v).length === 1 && typeof v.__ts === 'number') return admin.firestore.Timestamp.fromMillis(v.__ts);
    const o = {}; for (const k of Object.keys(v)) o[k] = revive(v[k]); return o;
  }
  return Array.isArray(v) ? v.map(revive) : v;
}
// ما يُنسخ: الحسابات (بدون كلمات مرور؛ لا تُخزَّن أصلًا في Firestore)، القادة، الوحدات، النشاطات، المنشورات وتعليقاتها وتفاعلاتها، الإشعارات، البلاغات، الإعدادات (بعد حذف الحقول الحساسة).
// ما لا يُنسخ: Firebase Authentication (كلمات المرور/الحسابات)، ملفات الصور في Google Drive، سجل النشاطات، بيانات النسخ نفسها.
const COLLECTIONS = ['users', 'leaders', 'units', 'unitPrivate', 'activities', 'announcements', 'siteNotifications', 'supportTickets', 'settings', 'gallery'];
const SUBS = { announcements: ['comments', 'reactions', 'saves'] };

async function collectAll() {
  const out = {};
  for (const c of COLLECTIONS) {
    const snap = await db.collection(c).get(); const docs = {};
    for (const d of snap.docs) {
      const entry = { data: serialize(d.data()), subs: {} };
      for (const sc of (SUBS[c] || [])) { const ss = await d.ref.collection(sc).get(); entry.subs[sc] = {}; ss.docs.forEach((x) => { entry.subs[sc][x.id] = serialize(x.data()); }); }
      docs[d.id] = entry;
    }
    out[c] = docs;
  }
  return out;
}
async function makeBackup(actor, label) {
  const payload = { schema: 1, createdAt: Date.now(), collections: COLLECTIONS, data: await collectAll() };
  const json = JSON.stringify(payload); const sha = crypto.createHash('sha256').update(json).digest('hex');
  const id = new Date().toISOString().replace(/[:.]/g, '-');
  const path = 'backups/' + id + '.json';
  await admin.storage().bucket().file(path).save(json, { contentType: 'application/json', resumable: false });
  const count = Object.values(payload.data).reduce((n, c) => n + Object.keys(c).length, 0);
  await db.collection('backups').doc(id).set({ createdAt: admin.firestore.FieldValue.serverTimestamp(), createdBy: actor.uid, label: label || 'manual', collections: COLLECTIONS, docCount: count, sizeKB: Math.round(json.length / 1024), sha256: sha, path });
  return { id, sha, count };
}

// ---------------------------------------------------------------- البريد
exports.sendAdminEmail = onCall({ secrets: [SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM] }, async (request) => {
  const actor = await requireGroupLeader(request);
  const { toUid, subject, body } = request.data || {};
  if (typeof toUid !== 'string' || !toUid || typeof subject !== 'string' || typeof body !== 'string') throw new HttpsError('invalid-argument', 'بيانات غير صالحة.');
  const s = subject.trim(), b = body.trim();
  if (s.length < 3 || s.length > 150 || b.length < 5 || b.length > 5000) throw new HttpsError('invalid-argument', 'طول الموضوع أو الرسالة غير مقبول.');
  // حدّ الإرسال: 10 رسائل في الساعة لكل مسؤول
  const rl = db.collection('emailRateLimits').doc(actor.uid); const now = Date.now();
  const ok = await db.runTransaction(async (t) => { const d = await t.get(rl); const arr = ((d.exists && d.data().times) || []).filter((x) => now - x < 3600000); if (arr.length >= 10) return false; arr.push(now); t.set(rl, { times: arr }); return true; });
  if (!ok) throw new HttpsError('resource-exhausted', 'تجاوزت حد الإرسال (10 رسائل/ساعة).');
  const target = await db.collection('users').doc(toUid).get();                // العنوان يُؤخذ من قاعدة البيانات ولا يُقبل من العميل
  const to = target.exists ? target.data().email : null;
  if (!to || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) throw new HttpsError('failed-precondition', 'لا يوجد بريد صالح لهذا الحساب.');
  const transport = nodemailer.createTransport({ host: SMTP_HOST.value(), port: Number(SMTP_PORT.value()), secure: Number(SMTP_PORT.value()) === 465, auth: { user: SMTP_USER.value(), pass: SMTP_PASS.value() } });
  try {
    const info = await transport.sendMail({ from: MAIL_FROM.value(), to, subject: s, text: b });
    await writeLog(actor, 'email_sent', 'user', toUid, to, 'ok:' + info.messageId);
    return { ok: true };
  } catch (e) {
    await writeLog(actor, 'email_failed', 'user', toUid, to, 'فشل SMTP');
    throw new HttpsError('internal', 'فشل الإرسال عبر خادم البريد.');
  }
});

// ---------------------------------------------------------------- النسخ الاحتياطي
exports.createBackup = onCall(async (request) => {
  const actor = await requireGroupLeader(request);
  const r = await makeBackup(actor, 'manual');
  await writeLog(actor, 'backup_create', 'backup', r.id, r.id, 'ok');
  return { id: r.id, docCount: r.count };
});
exports.getBackupDownloadUrl = onCall(async (request) => {
  const actor = await requireGroupLeader(request);
  const id = String((request.data || {}).id || ''); if (!/^[0-9TZ-]+$/.test(id)) throw new HttpsError('invalid-argument', 'معرّف غير صالح.');
  const [url] = await admin.storage().bucket().file('backups/' + id + '.json').getSignedUrl({ action: 'read', expires: Date.now() + 5 * 60 * 1000 });
  await writeLog(actor, 'backup_download', 'backup', id, id, 'ok');
  return { url };
});
exports.restoreBackup = onCall({ timeoutSeconds: 540, memory: '1GiB' }, async (request) => {
  const actor = await requireGroupLeader(request);
  const id = String((request.data || {}).id || ''); if (!/^[0-9TZ-]+$/.test(id)) throw new HttpsError('invalid-argument', 'معرّف غير صالح.');
  const meta = await db.collection('backups').doc(id).get(); if (!meta.exists) throw new HttpsError('not-found', 'النسخة غير موجودة.');
  const [buf] = await admin.storage().bucket().file(meta.data().path).download(); const json = buf.toString('utf8');
  // 1) التحقق من السلامة قبل أي كتابة
  const sha = crypto.createHash('sha256').update(json).digest('hex');
  if (sha !== meta.data().sha256) throw new HttpsError('data-loss', 'بصمة النسخة لا تطابق المسجّلة؛ أُلغيت الاستعادة.');
  let payload; try { payload = JSON.parse(json); } catch (e) { throw new HttpsError('data-loss', 'ملف النسخة تالف.'); }
  if (!payload || payload.schema !== 1 || typeof payload.data !== 'object') throw new HttpsError('data-loss', 'صيغة النسخة غير مدعومة.');
  // 2) نسخة أمان من الحالة الحالية قبل التنفيذ
  await makeBackup(actor, 'pre-restore-' + id);
  // 3) دمج (merge) دون حذف أي وثيقة موجودة
  let restored = 0, batch = db.batch(), n = 0;
  async function flush() { if (n) { await batch.commit(); batch = db.batch(); n = 0; } }
  for (const c of Object.keys(payload.data)) {
    if (!COLLECTIONS.includes(c)) continue;
    for (const [docId, entry] of Object.entries(payload.data[c])) {
      const ref = db.collection(c).doc(docId);
      batch.set(ref, revive(entry.data), { merge: true }); n++; restored++;
      for (const [sc, items] of Object.entries(entry.subs || {})) for (const [sid, sd] of Object.entries(items)) { batch.set(ref.collection(sc).doc(sid), revive(sd), { merge: true }); n++; restored++; }
      if (n >= 400) await flush();
    }
  }
  await flush();
  await writeLog(actor, 'backup_restore', 'backup', id, id, 'ok:' + restored);
  return { restored };
});
